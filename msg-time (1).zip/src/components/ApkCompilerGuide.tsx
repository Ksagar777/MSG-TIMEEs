import React, { useState, useEffect, useRef } from 'react';
import { 
  Smartphone, Terminal, Settings, Copy, Check, Cpu, Sparkles, Code, Play, RefreshCw, AlertCircle, HelpCircle, Download, ExternalLink, ShieldCheck, Heart, Github, Award
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function ApkCompilerGuide() {
  const [language, setLanguage] = useState<'hinglish' | 'english'>('hinglish');
  
  // App Config States
  const [appName, setAppName] = useState('Sagar School Bell');
  const [packageId, setPackageId] = useState('com.sagar.schoolbell');
  const [appVersion, setAppVersion] = useState('1.0.0');
  
  // Interactive UI States
  const [isCompiling, setIsCompiling] = useState(false);
  const [compileProgress, setCompileProgress] = useState(0);
  const [buildLogs, setBuildLogs] = useState<string[]>([]);
  const [buildSuccess, setBuildSuccess] = useState(false);
  const [activeMethod, setActiveMethod] = useState<'github' | 'capacitor' | 'volt'>('github');
  
  // Copy feedback states
  const [copiedConfig, setCopiedConfig] = useState(false);
  const [copiedWorkflow, setCopiedWorkflow] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<number | null>(null);

  const logEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll logs to bottom
  useEffect(() => {
    if (logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [buildLogs]);

  // Live Generated capacitor.config.ts
  const capacitorConfig = `import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: '${packageId.toLowerCase().trim()}',
  appName: '${appName}',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: {
    // Enable connection to local ESP32 / mDNS
    cleartext: true,
    allowNavigation: ['schoolbell.local', '192.168.1.*']
  },
  android: {
    allowMixedContent: true
  }
};

export default config;`;

  // Live Generated GitHub Actions Workflows configuration (.github/workflows/android.yml)
  const githubWorkflowYaml = `name: Build Android APK (Free Cloud Compiler)

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    name: Build Android Debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'zulu'

      - name: Install Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20
          # cache: 'npm' # Commented out to prevent "lock file not found" error if package-lock.json is missing

      - name: Install Dependencies
        run: npm ci || npm install

      - name: Build React Production Assets
        run: npm run build

      - name: Install Capacitor CLI & Android Platform
        run: |
          npm install @capacitor/core @capacitor/cli
          npm install @capacitor/android

      - name: Generate Capacitor Configuration
        run: |
          cat <<EOF > capacitor.config.ts
          import { CapacitorConfig } from '@capacitor/cli';
          const config: CapacitorConfig = {
            appId: '${packageId.toLowerCase().trim()}',
            appName: '${appName}',
            webDir: 'dist',
            bundledWebRuntime: false,
            server: {
              cleartext: true,
              allowNavigation: ['schoolbell.local', '192.168.1.*']
            },
            android: {
              allowMixedContent: true
            }
          };
          export default config;
          EOF

      - name: Add Android Native Project & Sync
        run: |
          npx cap add android || true
          npx cap sync

      - name: Build Android APK with Gradle
        run: |
          cd android
          chmod +x gradlew
          ./gradlew assembleDebug

      - name: Upload Compiled APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: ${appName.replace(/\s+/g, '')}-APK
          path: android/app/build/outputs/apk/debug/app-debug.apk`;

  // Standard Terminal Commands for Local Compile
  const commandsList = [
    {
      title: language === 'hinglish' ? "1. Capacitor Core & CLI इंस्टॉल करें" : "1. Install Capacitor CLI",
      cmd: `npm install @capacitor/core @capacitor/cli`
    },
    {
      title: language === 'hinglish' ? "2. प्रोजेक्ट इनिशियलाइज़ करें" : "2. Initialize Config File",
      cmd: `npx cap init "${appName}" "${packageId}" --web-dir=dist`
    },
    {
      title: language === 'hinglish' ? "3. React वेब प्रोजेक्ट बिल्ड करें" : "3. Compile React Web Assets",
      cmd: `npm run build`
    },
    {
      title: language === 'hinglish' ? "4. एंड्रॉइड प्लेटफॉर्म जोड़ें" : "4. Integrate Android Platform",
      cmd: `npm install @capacitor/android && npx cap add android`
    },
    {
      title: language === 'hinglish' ? "5. कोड सिंक करें और एंड्रॉइड स्टूडियो खोलें" : "5. Sync Assets & Launch Android Studio",
      cmd: `npx cap sync && npx cap open android`
    }
  ];

  const handleCopyConfig = () => {
    navigator.clipboard.writeText(capacitorConfig);
    setCopiedConfig(true);
    setTimeout(() => setCopiedConfig(false), 2000);
  };

  const handleCopyWorkflow = () => {
    navigator.clipboard.writeText(githubWorkflowYaml);
    setCopiedWorkflow(true);
    setTimeout(() => setCopiedWorkflow(false), 2000);
  };

  const handleCopyCmd = (cmdText: string, index: number) => {
    navigator.clipboard.writeText(cmdText);
    setCopiedCmd(index);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  // Simulating the Gradle compilation steps
  const startSimulation = () => {
    if (isCompiling) return;
    setIsCompiling(true);
    setCompileProgress(0);
    setBuildSuccess(false);
    setBuildLogs([]);

    const logSteps = [
      `[GEMINI-COMPILER] Initializing Android Cloud workspace...`,
      `[GEMINI-COMPILER] Environment: Ubuntu 22.04 LTS (x86_64)`,
      `[JDK-SETUP] Java Development Kit v17.0.8 (Zulu) configured successfully.`,
      `[NODE-SETUP] Node.js v20.11.0 with npm v10.2.4 configured.`,
      `[GIT-WORKFLOW] Workspace repo directory initialized.`,
      `[VITE-BUILD] Compiling React Vite source assets for production...`,
      `[VITE-BUILD] ✓ 46 modules transformed.`,
      `[VITE-BUILD] dist/index.html                     1.12 KiB`,
      `[VITE-BUILD] dist/assets/index-D7A492F.css      33.40 KiB`,
      `[VITE-BUILD] dist/assets/index-F48E89A.js      148.90 KiB`,
      `[CAPACITOR] Creating configuration file "capacitor.config.ts"...`,
      `[CAPACITOR] Package ID: "${packageId}" | App Name: "${appName}"`,
      `[CAPACITOR] Synchronizing web assets with Native Android project...`,
      `[CAPACITOR] Copying "dist" directory to "android/app/src/main/assets/public"...`,
      `[CAPACITOR] Injecting Capacitor plugins and native Java bridges...`,
      `[GRADLE-BUILD] Executing: "./gradlew assembleDebug" inside native wrapper...`,
      `[GRADLE] > Starting Daemon (using JDK 17)`,
      `[GRADLE] > Configure project :app`,
      `[GRADLE] > Task :app:preBuild UP-TO-DATE`,
      `[GRADLE] > Task :app:compileDebugJavaWithJavac`,
      `[GRADLE] > Task :app:processDebugResources`,
      `[GRADLE] > Task :app:compileDebugKotlinWithKotlinc`,
      `[GRADLE] > Task :app:dexBuilderDebug`,
      `[GRADLE] > Task :app:mergeProjectDexDebug`,
      `[GRADLE] > Task :app:packageDebug`,
      `[GRADLE] > Task :app:assembleDebug`,
      `[SUCCESS] Android Gradle build completed in 5.12 seconds!`,
      `[SIGN-TOOL] Debug keystore auto-signed: app-debug.apk (SHA-256 generated).`,
      `[COMPILER] SUCCESS: Android APK compiled! File: "${appName.replace(/\s+/g, '')}-debug.apk" (4.3 MB)`
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < logSteps.length) {
        setBuildLogs(prev => [...prev, logSteps[currentStep]]);
        setCompileProgress(Math.floor(((currentStep + 1) / logSteps.length) * 100));
        currentStep++;
      } else {
        clearInterval(interval);
        setIsCompiling(false);
        setBuildSuccess(true);
      }
    }, 120);
  };

  return (
    <div className="space-y-6" id="apk-compiler-guide-section">
      
      {/* Control Bar */}
      <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="font-bold text-white text-base flex items-center gap-2 uppercase tracking-wider">
            <Smartphone className="h-5 w-5 text-[#F27D26]" />
            Modern Android APK Compiler & Wrapper
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            {language === 'hinglish' 
              ? 'बिना MIT App Inventor के, इस सुन्दर React UI को असली Android App (APK) में बदलने का आधुनिक तरीका'
              : 'The modern way to wrap this React dashboard into a professional native Android APK'
            }
          </p>
        </div>

        {/* Language Selector */}
        <div className="bg-[#0F1115] p-1 rounded-lg flex text-xs font-bold border border-[#2A2D35] self-start sm:self-center">
          <button
            onClick={() => setLanguage('hinglish')}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer ${language === 'hinglish' ? 'bg-[#F27D26] text-white shadow-md' : 'text-gray-400 hover:text-white'}`}
          >
            Hinglish (हिंदी)
          </button>
          <button
            onClick={() => setLanguage('english')}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer ${language === 'english' ? 'bg-[#F27D26] text-white shadow-md' : 'text-gray-400 hover:text-white'}`}
          >
            English
          </button>
        </div>
      </div>

      {/* Intro Alert */}
      <div className="bg-gradient-to-r from-[#F27D26]/10 to-[#00FF9C]/5 border border-[#F27D26]/20 rounded-2xl p-5 text-left text-xs leading-relaxed text-gray-300 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-32 h-32 bg-[#F27D26]/10 rounded-full blur-2xl pointer-events-none" />
        <div className="flex gap-3 items-start">
          <div className="p-2 bg-[#F27D26]/10 text-[#F27D26] rounded-xl border border-[#F27D26]/20">
            <Sparkles className="h-4 w-4 animate-pulse text-[#F27D26]" />
          </div>
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider mb-1 flex items-center gap-1.5">
              {language === 'hinglish' ? 'Gemini AI स्पष्टीकरण और समाधान' : 'Gemini AI Explanation & Solution'}
            </h4>
            <p>
              {language === 'hinglish' ? (
                <>
                  यह एक <strong>React Vite Web App</strong> है। क्लाउड के ब्राउज़र-आधारित सैंडबॉक्स एनवायरनमेंट में सीधे मोबाइल APK कम्पाइलर रन नहीं हो सकता (क्योंकि यहाँ Android SDK और Gradle उपलब्ध नहीं है)। 
                  परंतु, आपको पुराने <strong>MIT App Inventor</strong> में जाने की बिल्कुल ज़रूरत नहीं है! आप सीधे इस सुन्दर, मॉडर्न और एनीमेशन वाले React वेब यूआई को <strong>Capacitor (by Ionic)</strong> के ज़रिए असली एंड्रॉइड ऐप (APK) बना सकते हैं। यह ऐप बिल्कुल नेटिव लगेगा और बैकग्राउंड में बिना किसी रुकावट के काम करेगा।
                </>
              ) : (
                <>
                  This is a modern <strong>React Vite Web App</strong>. Because this cloud development environment runs in a sandboxed browser, direct native JDK/Gradle mobile compilations cannot run on the server.
                  However, you do NOT need to settle for <strong>MIT App Inventor's</strong> basic design! You can easily package this modern, reactive dashboard with beautiful animations into a native APK using <strong>Capacitor (by Ionic)</strong>.
                </>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Compiler Options Tab Switcher */}
      <div className="grid grid-cols-3 gap-2 bg-[#1A1D24] p-1.5 rounded-2xl border border-[#2A2D35] text-xs font-bold">
        <button
          onClick={() => setActiveMethod('github')}
          className={`py-3 px-2 rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-2 ${
            activeMethod === 'github' 
              ? 'bg-[#F27D26] text-white shadow-lg' 
              : 'text-gray-400 hover:text-white hover:bg-[#0F1115]/50'
          }`}
        >
          <Github className="h-4 w-4" />
          <span className="text-center">
            {language === 'hinglish' ? '1. Free GitHub Cloud (बिना पीसी के)' : '1. Free GitHub Build'}
          </span>
        </button>

        <button
          onClick={() => setActiveMethod('capacitor')}
          className={`py-3 px-2 rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-2 ${
            activeMethod === 'capacitor' 
              ? 'bg-[#F27D26] text-white shadow-lg' 
              : 'text-gray-400 hover:text-white hover:bg-[#0F1115]/50'
          }`}
        >
          <Cpu className="h-4 w-4" />
          <span className="text-center">
            {language === 'hinglish' ? '2. Local PC Build (कमांड द्वारा)' : '2. Local PC Build'}
          </span>
        </button>

        <button
          onClick={() => setActiveMethod('volt')}
          className={`py-3 px-2 rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-2 ${
            activeMethod === 'volt' 
              ? 'bg-[#F27D26] text-white shadow-lg' 
              : 'text-gray-400 hover:text-white hover:bg-[#0F1115]/50'
          }`}
        >
          <ExternalLink className="h-4 w-4" />
          <span className="text-center">
            {language === 'hinglish' ? '3. VoltBuilder (वेबसाइट द्वारा)' : '3. VoltBuilder'}
          </span>
        </button>
      </div>

      {/* Main Grid Options */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left 5 Columns: App Configurator & Live Capacitor config generator */}
        <div className="lg:col-span-5 space-y-6 text-left">
          
          {/* Configure Panel */}
          <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl p-5 shadow-xl space-y-4">
            <h3 className="font-bold text-white text-xs uppercase tracking-wider font-mono border-b border-[#2A2D35] pb-2 flex items-center gap-1.5">
              <Settings className="h-4 w-4 text-[#F27D26]" />
              {language === 'hinglish' ? 'ऐप की जानकारी भरें' : 'Configure App Metadata'}
            </h3>
            
            <div className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-[10px] font-bold text-gray-400 block mb-1 uppercase tracking-wider">App Display Name</label>
                <input 
                  type="text" 
                  value={appName}
                  onChange={(e) => setAppName(e.target.value)}
                  className="w-full border border-[#2A2D35] rounded-lg p-2.5 text-xs text-white bg-[#0F1115] focus:outline-none focus:border-[#F27D26] font-bold"
                  placeholder="e.g. Sagar School Bell"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-gray-400 block mb-1 uppercase tracking-wider">Package Identifier (Unique ID)</label>
                <input 
                  type="text" 
                  value={packageId}
                  onChange={(e) => setPackageId(e.target.value)}
                  className="w-full border border-[#2A2D35] rounded-lg p-2.5 text-xs text-white bg-[#0F1115] focus:outline-none focus:border-[#F27D26]"
                  placeholder="e.g. com.sagar.schoolbell"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-gray-400 block mb-1 uppercase tracking-wider">Version</label>
                  <input 
                    type="text" 
                    value={appVersion}
                    onChange={(e) => setAppVersion(e.target.value)}
                    className="w-full border border-[#2A2D35] rounded-lg p-2.5 text-xs text-white bg-[#0F1115] text-center focus:outline-none focus:border-[#F27D26]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-gray-400 block mb-1 uppercase tracking-wider">Engine Platform</label>
                  <div className="w-full border border-[#2A2D35] rounded-lg p-2.5 text-xs text-gray-400 bg-[#0F1115] text-center font-bold">
                    Capacitor Native
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* capacitor.config.ts Live Preview */}
          <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex justify-between items-center border-b border-[#2A2D35] pb-2">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider font-mono flex items-center gap-1.5">
                <Code className="h-4 w-4 text-[#00FF9C]" />
                capacitor.config.ts
              </h3>
              <button
                onClick={handleCopyConfig}
                className="text-gray-400 hover:text-white text-xs font-mono flex items-center gap-1 bg-[#0F1115] border border-[#2A2D35] px-2.5 py-1 rounded-lg hover:border-gray-500 transition-all cursor-pointer"
              >
                {copiedConfig ? (
                  <>
                    <Check className="h-3 w-3.5 text-[#00FF9C]" /> {language === 'hinglish' ? 'कॉपी हो गया' : 'Copied!'}
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3.5 text-[#F27D26]" /> Copy Config
                  </>
                )}
              </button>
            </div>

            <div className="bg-[#0F1115] rounded-2xl border border-[#2A2D35] p-4 text-[11px] font-mono text-gray-300 leading-relaxed overflow-x-auto">
              <pre>{capacitorConfig}</pre>
            </div>
          </div>

        </div>

        {/* Right 7 Columns: Dynamic Viewport based on selected Tab */}
        <div className="lg:col-span-7 space-y-6 text-left">
          
          {/* METHOD 1: GITHUB ACTIONS (PREFERED FREE CLOUD BUILDER) */}
          {activeMethod === 'github' && (
            <div className="space-y-6">
              
              {/* Informational Hero Card */}
              <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl p-6 shadow-xl space-y-4">
                <div className="flex items-center gap-2 pb-3 border-b border-[#2A2D35]">
                  <span className="p-1.5 bg-[#00FF9C]/10 text-[#00FF9C] rounded-lg border border-[#00FF9C]/20">
                    <Github className="h-5 w-5" />
                  </span>
                  <h3 className="font-bold text-white text-base uppercase tracking-wider font-mono">
                    {language === 'hinglish' ? '100% Free Cloud Android Compiler' : '100% Free Cloud Android Compiler'}
                  </h3>
                </div>

                <p className="text-xs text-gray-400 leading-relaxed">
                  {language === 'hinglish' ? (
                    <>
                      <strong>GitHub Actions</strong> एक बिल्कुल मुफ्त क्लाउड कंपाइलर है जो बिना आपके कंप्यूटर पर भारी-भरकम Android Studio या JDK सेटअप किए, सीधे इंटरनेट पर ही आपके लिए <code>app-debug.apk</code> फ़ाइल तैयार कर देता है। 
                      आपको बस एक मुफ्त GitHub अकाउंट चाहिए!
                    </>
                  ) : (
                    <>
                      <strong>GitHub Actions</strong> is a 100% free CI/CD platform. It spins up a remote Ubuntu server, installs JDK/Android SDK, builds your React code, compiles the APK, and gives you a direct link to download it!
                    </>
                  )}
                </p>

                {/* Direct Action Steps */}
                <div className="space-y-3.5 text-xs">
                  <h4 className="font-extrabold text-[#F27D26] uppercase tracking-wider text-[11px] font-mono">
                    {language === 'hinglish' ? '🚀 APK डाउनलोड करने के स्टेप्स:' : '🚀 Step-by-Step Instructions:'}
                  </h4>
                  <ul className="space-y-2 list-decimal list-inside text-gray-300">
                    <li>{language === 'hinglish' ? 'ऊपर बाएँ कोने से "Settings" में जाकर इस प्रोजेक्ट की ZIP फ़ाइल एक्सपोर्ट (Export ZIP) करें।' : 'Export this React project code as a ZIP file from the Settings panel.'}</li>
                    <li>{language === 'hinglish' ? 'मुफ्त GitHub अकाउंट बनाकर एक नया Repository (उदा. "school-bell") बनाएँ।' : 'Go to GitHub.com, sign up for free, and create a new Repository.'}</li>
                    <li>{language === 'hinglish' ? 'प्रोजेक्ट की फाइलों को GitHub रिपोजिटरी में अपलोड करें।' : 'Upload/push your unzipped project files into that repository.'}</li>
                    <li>
                      {language === 'hinglish' ? (
                        <>
                          प्रोजेक्ट में <code>.github/workflows/</code> फोल्डर बनाएँ और उसमें <code>android.yml</code> फाइल बनाकर नीचे दिया गया कोड पेस्ट कर दें।
                        </>
                      ) : (
                        <>
                          Create a directory <code>.github/workflows/</code> and save the code below as <code>android.yml</code>.
                        </>
                      )}
                    </li>
                    <li>
                      {language === 'hinglish' ? (
                        <>
                          अपलोड करते ही GitHub बैकग्राउंड में ऑटोमैटिकली आपका APK बनाना शुरू कर देगा! <strong>Actions</strong> टैब में जाकर आप लाइव कंपाइलेशन देख सकते हैं और कम्प्लीट होने पर APK डाउनलोड कर सकते हैं।
                        </>
                      ) : (
                        <>
                          Once uploaded, GitHub automatically starts compiling! Go to your repo's <strong>Actions</strong> tab to monitor build logs and download the signed APK.
                        </>
                      )}
                    </li>
                  </ul>
                </div>
              </div>

              {/* GitHub Workflow YAML Generator */}
              <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl p-5 shadow-xl space-y-3">
                <div className="flex justify-between items-center border-b border-[#2A2D35] pb-2">
                  <h3 className="font-bold text-white text-xs uppercase tracking-wider font-mono flex items-center gap-1.5">
                    <Code className="h-4 w-4 text-[#F27D26]" />
                    .github/workflows/android.yml
                  </h3>
                  <button
                    onClick={handleCopyWorkflow}
                    className="text-gray-400 hover:text-white text-xs font-mono flex items-center gap-1 bg-[#0F1115] border border-[#2A2D35] px-2.5 py-1 rounded-lg hover:border-gray-500 transition-all cursor-pointer"
                  >
                    {copiedWorkflow ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-[#00FF9C]" /> {language === 'hinglish' ? 'कॉपी हो गया' : 'Copied!'}
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5 text-[#F27D26]" /> Copy Workflow Code
                      </>
                    )}
                  </button>
                </div>

                <div className="bg-[#0F1115] rounded-2xl border border-[#2A2D35] p-4 text-[10.5px] font-mono text-gray-300 leading-relaxed overflow-x-auto max-h-[400px]">
                  <pre>{githubWorkflowYaml}</pre>
                </div>
              </div>

            </div>
          )}

          {/* METHOD 2: LOCAL PC COMPILER (CAPACITOR + ANDROID STUDIO) */}
          {activeMethod === 'capacitor' && (
            <div className="space-y-6">
              
              {/* Visual Compiler Terminal Container */}
              <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl shadow-xl overflow-hidden flex flex-col min-h-[380px]">
                
                {/* Terminal Header */}
                <div className="bg-[#15181F] border-b border-[#2A2D35] p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1.5">
                      <span className="w-3 h-3 rounded-full bg-red-500 block" />
                      <span className="w-3 h-3 rounded-full bg-yellow-500 block" />
                      <span className="w-3 h-3 rounded-full bg-green-500 block" />
                    </div>
                    <span className="h-4 w-px bg-[#2A2D35] mx-1" />
                    <span className="text-xs font-bold font-mono text-gray-300 uppercase tracking-widest flex items-center gap-1.5">
                      <Terminal className="h-4 w-4 text-[#F27D26]" />
                      Local Compiler Simulation
                    </span>
                  </div>

                  {/* Run Trigger */}
                  <button
                    onClick={startSimulation}
                    disabled={isCompiling}
                    className={`px-4 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer transition-all uppercase tracking-wider ${
                      isCompiling 
                        ? 'bg-gray-800 text-gray-500 cursor-not-allowed' 
                        : 'bg-[#F27D26] hover:bg-[#d66b1d] text-white shadow-md hover:scale-[1.02]'
                    }`}
                  >
                    {isCompiling ? (
                      <>
                        <RefreshCw className="h-3.5 w-3.5 animate-spin" /> {language === 'hinglish' ? 'कम्पाइल हो रहा है...' : 'Compiling...'}
                      </>
                    ) : (
                      <>
                        <Play className="h-3.5 w-3.5 fill-current" /> {language === 'hinglish' ? 'बिल्ड सिमुलेट करें' : 'Simulate APK Build'}
                      </>
                    )}
                  </button>
                </div>

                {/* Terminal Console Viewport */}
                <div className="bg-[#0F1115] p-5 flex-grow font-mono text-[11px] leading-relaxed text-gray-300 overflow-y-auto max-h-[300px] min-h-[220px] space-y-1.5 text-left flex flex-col justify-end">
                  {buildLogs.length === 0 ? (
                    <div className="my-auto text-center space-y-3 p-6 text-gray-500 font-sans">
                      <Smartphone className="h-10 w-10 text-gray-600 mx-auto animate-bounce" />
                      <p className="text-xs">
                        {language === 'hinglish' 
                          ? 'ऊपर "बिल्ड सिमुलेट करें" बटन दबाकर देखें कि एंड्रॉइड बिल्ड कंपाइलर कैसे वेब कोड को APK में बंडल करता है!'
                          : 'Click "Simulate APK Build" to see the terminal compiler bundle this React app step-by-step!'
                        }
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {buildLogs.map((log, index) => {
                        if (!log || typeof log !== 'string') return null;
                        let logColor = 'text-gray-400';
                        if (log.startsWith('[SUCCESS]')) logColor = 'text-[#00FF9C] font-bold';
                        else if (log.startsWith('[COMPILER]')) logColor = 'text-yellow-400 font-semibold';
                        else if (log.startsWith('[VITE-BUILD]')) logColor = 'text-sky-400';
                        else if (log.startsWith('[CAPACITOR]')) logColor = 'text-[#F27D26]';
                        else if (log.startsWith('[GRADLE]')) logColor = 'text-purple-400';

                        return (
                          <div key={index} className={`${logColor} font-mono tracking-wide`}>
                            {log}
                          </div>
                        );
                      })}
                      <div ref={logEndRef} />
                    </div>
                  )}
                </div>

                {/* Compilation Progress Bar */}
                {isCompiling && (
                  <div className="bg-[#15181F] px-5 py-3 border-t border-[#2A2D35] flex items-center justify-between font-mono text-[10px]">
                    <span className="text-[#F27D26] animate-pulse">Running task...</span>
                    <div className="flex-grow mx-4 h-2 bg-gray-800 rounded-full overflow-hidden relative border border-[#2A2D35]">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${compileProgress}%` }}
                        transition={{ ease: "easeInOut" }}
                        className="h-full bg-gradient-to-r from-[#F27D26] to-[#00FF9C] rounded-full"
                      />
                    </div>
                    <span className="text-white font-bold">{compileProgress}%</span>
                  </div>
                )}

                {/* Build Success Card Trigger */}
                <AnimatePresence>
                  {buildSuccess && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 20 }}
                      className="bg-gradient-to-r from-[#00FF9C]/10 via-[#00FF9C]/5 to-transparent border-t border-[#00FF9C]/20 p-5 text-left"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-[#00FF9C]/10 text-[#00FF9C] rounded-xl border border-[#00FF9C]/20 shrink-0">
                          <ShieldCheck className="h-5 w-5" />
                        </div>
                        <div className="flex-grow">
                          <h4 className="font-bold text-[#00FF9C] text-xs uppercase tracking-wider font-mono">
                            {language === 'hinglish' ? 'बिल्ड पूरा हुआ: app-debug.apk तैयार है' : 'Build Success: app-debug.apk Generated'}
                          </h4>
                          <p className="text-xs text-gray-300 mt-1 leading-relaxed">
                            {language === 'hinglish' ? (
                              <>
                                वर्चुअल कंपाइलर ने <strong>Sagar School Bell App v1.0.0</strong> को सफलतापूर्वक बना दिया है! 
                                अपने खुद के कंप्यूटर/लैपटॉप पर इस बिल्ड को वास्तविक रूप देने के लिए नीचे दिए गए स्टेप्स का इस्तेमाल करें।
                              </>
                            ) : (
                              <>
                                The virtual compiler has successfully signed and built <strong>Sagar School Bell App v1.0.0</strong>.
                                Follow the terminal steps below to compile this on your local system or machine.
                              </>
                            )}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>

              {/* Quick Terminal Guide Steps */}
              <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl p-6 shadow-xl space-y-4">
                <h3 className="font-bold text-white text-xs uppercase tracking-wider font-mono border-b border-[#2A2D35] pb-2 flex items-center gap-1.5">
                  <Cpu className="h-4 w-4 text-[#F27D26]" />
                  {language === 'hinglish' ? 'अपने कंप्यूटर पर APK कम्पाइल करने के स्टेप्स' : 'How to Compile the APK on your PC'}
                </h3>

                <p className="text-xs text-gray-400 leading-relaxed">
                  {language === 'hinglish' ? (
                    <>
                      इस पूरे React वेब प्रोजेक्ट को अपने लैपटॉप में डाउनलोड करें (या zip फाइल निकालें), फिर अपने टर्मिनल/कमांड प्रॉम्ट (CMD) में नीचे दिए गए निर्देश केवल एक बार रन करें:
                    </>
                  ) : (
                    <>
                      Download/export this React project ZIP to your local laptop, open your terminal (CMD) inside the project folder, and execute these commands sequentially:
                    </>
                  )}
                </p>

                <div className="space-y-4">
                  {commandsList.map((item, index) => (
                    <div key={index} className="space-y-1.5 text-left">
                      <span className="text-[11px] font-bold text-gray-300 font-sans block">{item.title}</span>
                      <div className="flex items-center gap-2 bg-[#0F1115] border border-[#2A2D35] rounded-xl p-2.5 font-mono text-xs text-white">
                        <span className="text-gray-500 select-none">$</span>
                        <span className="flex-grow select-all font-mono text-[11px] text-gray-300 overflow-x-auto whitespace-nowrap">{item.cmd}</span>
                        <button
                          onClick={() => handleCopyCmd(item.cmd, index)}
                          className="text-gray-500 hover:text-white transition-all cursor-pointer p-1"
                          title="Copy command"
                        >
                          {copiedCmd === index ? (
                            <Check className="h-3.5 w-3.5 text-[#00FF9C]" />
                          ) : (
                            <Copy className="h-3.5 w-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-gradient-to-r from-blue-950/20 to-transparent border border-blue-900/30 rounded-2xl p-4 mt-4 text-xs text-gray-300 flex gap-3 items-start leading-relaxed">
                  <HelpCircle className="h-5 w-5 text-sky-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-sans">{language === 'hinglish' ? 'अंतिम निर्देश (After Android Studio Opens):' : 'Final Step inside Android Studio:'}</strong>
                    {language === 'hinglish' ? (
                      <>
                        जब <code>npx cap open android</code> कमांड रन होगी, तो यह खुद ही <strong>Android Studio</strong> खोल देगी। वहाँ केवल 5 सेकंड इंतज़ार करें ताकि Gradle सिंक हो जाए, फिर ऊपर की मेनू बार में <strong>Build ➔ Build Bundle(s) / APK(s) ➔ Build APK(s)</strong> पर क्लिक करें। आपका असली APK तैयार होकर आपको मिल जाएगा!
                      </>
                    ) : (
                      <>
                        After running the final command, <strong>Android Studio</strong> will automatically launch with your native project. Just wait a few seconds for Gradle synchronization to finish, then go to the top menu: <strong>Build ➔ Build Bundle(s) / APK(s) ➔ Build APK(s)</strong>. Your real APK is ready!
                      </>
                    )}
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* METHOD 3: VOLTBUILDER */}
          {activeMethod === 'volt' && (
            <div className="space-y-6">
              <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl p-6 shadow-xl space-y-4">
                <div className="flex items-center gap-2 pb-3 border-b border-[#2A2D35]">
                  <span className="p-1.5 bg-[#00FF9C]/10 text-[#00FF9C] rounded-lg border border-[#00FF9C]/20">
                    <ExternalLink className="h-5 w-5" />
                  </span>
                  <h3 className="font-bold text-white text-base uppercase tracking-wider font-mono">
                    {language === 'hinglish' ? 'VoltBuilder (No-Code Drag-and-Drop Compiler)' : 'VoltBuilder Cloud Compiler'}
                  </h3>
                </div>

                <p className="text-xs text-gray-400 leading-relaxed">
                  {language === 'hinglish' ? (
                    <>
                      <strong>VoltBuilder</strong> एक बेहतरीन और लोकप्रिय थर्ड-पार्टी क्लाउड कंपाइलर वेबसाइट है। यहाँ आपको अपने पीसी में कोई कोडिंग सॉफ्टवेयर या कोडिंग टूल्स डालने की बिल्कुल भी आवश्यकता नहीं है।
                    </>
                  ) : (
                    <>
                      <strong>VoltBuilder</strong> is an excellent web-based platform that compiles React and Apache Cordova projects into ready-to-use APK files in less than 60 seconds directly inside your browser.
                    </>
                  )}
                </p>

                <div className="space-y-3 text-xs leading-relaxed text-gray-300">
                  <h4 className="font-extrabold text-[#F27D26] uppercase tracking-wider text-[11px] font-mono">
                    {language === 'hinglish' ? '🛠️ VoltBuilder से APK कैसे बनाएँ:' : '🛠️ How to use VoltBuilder:'}
                  </h4>
                  <ul className="space-y-2 list-decimal list-inside">
                    <li>{language === 'hinglish' ? 'Settings मेनू से इस पूरे प्रोजेक्ट का "Export ZIP" डाउनलोड करें।' : 'Export and download the full workspace codebase as a ZIP archive.'}</li>
                    <li>{language === 'hinglish' ? 'मुफ्त अकाउंट के लिए ' : 'Go to '} <a href="https://volt.build/" target="_blank" rel="noreferrer" className="text-[#F27D26] hover:underline font-bold">Volt.build</a> {language === 'hinglish' ? 'पर जाएँ।' : 'website.'}</li>
                    <li>{language === 'hinglish' ? 'अपने ZIP फाइल को वहाँ अपलोड (Upload) करें।' : 'Drag and drop your exported project ZIP file into their browser compiler area.'}</li>
                    <li>{language === 'hinglish' ? 'VoltBuilder खुद आपके कोड को डिटेक्ट करेगा और आपके लिए APK कम्पाइल कर देगा।' : 'VoltBuilder automatically resolves dependencies and initiates cloud packaging.'}</li>
                    <li>{language === 'hinglish' ? 'कंपाइल होते ही आपके स्क्रीन पर और ईमेल पर सीधे डाउनलोड लिंक आ जाएगा!' : 'Once compiled, a direct APK download link is generated on your dashboard and sent to your email!'}</li>
                  </ul>
                </div>

                <div className="p-4 bg-[#F27D26]/5 border border-[#F27D26]/20 rounded-2xl flex gap-3 items-center mt-2">
                  <Award className="h-5 w-5 text-[#F27D26] shrink-0" />
                  <p className="text-xs text-gray-300">
                    {language === 'hinglish' 
                      ? 'यदि आप बिना कोडिंग या बिना गिटहब के तुरंत एक ट्रायल एपीके इंस्टॉल करना चाहते हैं, तो यह सबसे बेस्ट और आसान तरीका है!'
                      : 'If you want to test and run the APK on your phone right away with zero local requirements, this is a perfect trial route!'
                    }
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
