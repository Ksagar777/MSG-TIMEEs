import React, { useState } from 'react';
import { Copy, Check, Terminal, Info, Zap, AlertTriangle, ShieldCheck, Cpu, HardDrive } from 'lucide-react';

export default function FirmwareGuide() {
  const [copied, setCopied] = useState<boolean>(false);
  const [copiedStm, setCopiedStm] = useState<boolean>(false);
  const [language, setLanguage] = useState<'hinglish' | 'english'>('hinglish');

  const espCode = `/*
  ========================================================================
  🔔 HYPER-OPTIMIZED & 1MB COMPATIBLE ESP32 FIRMWARE
  ========================================================================
  Features:
    1. 🟢 Direct WiFi connection to save huge space (No WiFiMulti)
    2. 🟢 Non-volatile Preferences to keep schedules after power cuts
    3. 🟢 NTP Time correction synced to STM32 hourly
    4. 🟢 Optional mDNS toggle (Comments out mDNS to save 120KB+ size!)
  ========================================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <time.h>
#include <Preferences.h>

// 🔴 1MB LIMIT SE BHI CHHOTA KRNE KE LIYE IS LINE KO COMMENT KAREIN (Saves 120KB+):
#define USE_MDNS 1

#ifdef USE_MDNS
#include <ESPmDNS.h>
#endif

WebServer server(80);
Preferences prefs;

const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 19800; // IST (+5:30)
const int   daylightOffset_sec = 0;
unsigned long lastSync = 0;

// Multiple WiFi Network details (Saves huge flash space vs WiFiMulti)
const char* APs[][2] = {
  {"MSG", "MSG493558"},
  {"B O_OFFICE", "Office@111"}
};

void syncTime() {
  struct tm t;
  if(!getLocalTime(&t)) return;
  char buf[40];
  strftime(buf, sizeof(buf), "TIME:%H:%M:%S:%d:%m:%Y", &t);
  Serial2.println(buf);
}

void restoreBells() {
  for (int i = 1; i <= 12; i++) {
    String p = String(i);
    if (prefs.isKey(("h_" + p).c_str())) {
      int h = prefs.getInt(("h_" + p).c_str(), 0);
      int m = prefs.getInt(("m_" + p).c_str(), 0);
      int d = prefs.getInt(("d_" + p).c_str(), 0);
      Serial2.printf("BELL:%d:%d:%d:%d\\n", i, h, m, d);
      delay(80);
    }
  }
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(9600, SERIAL_8N1, 16, 17);
  prefs.begin("bell", false);

  // Elegant, lightweight multi-AP connection
  WiFi.mode(WIFI_STA);
  bool connected = false;
  for (int i = 0; i < 2; i++) {
    Serial.printf("Connecting to: %s\\n", APs[i][0]);
    WiFi.begin(APs[i][0], APs[i][1]);
    int retries = 0;
    while (WiFi.status() != WL_CONNECTED && retries < 15) {
      delay(400);
      Serial.print(".");
      retries++;
    }
    if (WiFi.status() == WL_CONNECTED) {
      connected = true;
      Serial.println("\\nConnected!");
      break;
    }
  }

#ifdef USE_MDNS
  MDNS.begin("schoolbell");
  MDNS.addService("http", "tcp", 80);
#endif

  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  delay(1000);
  syncTime();
  restoreBells();

  server.on("/", []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(200, "text/plain", "Bell OK");
  });

  server.on("/api/health", []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(200, "text/plain", "OK");
  });

  server.on("/updateBell", []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    String p = server.arg("period");
    String h = server.arg("hour");
    String m = server.arg("minute");
    String d = server.arg("duration");
    
    int id = p.toInt();
    prefs.putInt(("h_" + p).c_str(), h.toInt());
    prefs.putInt(("m_" + p).c_str(), m.toInt());
    prefs.putInt(("d_" + p).c_str(), d.toInt());

    Serial2.printf("BELL:%d:%d:%d:%d\\n", id, h.toInt(), m.toInt(), d.toInt());
    server.send(200, "text/plain", "OK");
  });

  server.on("/addHoliday", []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    String cmd = "HOLIDAY:" + server.arg("date");
    Serial2.println(cmd);
    server.send(200, "text/plain", "OK");
  });

  server.on("/manualBell", []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    String cmd = "MANUAL:" + server.arg("status");
    Serial2.println(cmd);
    server.send(200, "text/plain", "OK");
  });

  server.begin();
}

void loop() {
  server.handleClient();
  if (millis() - lastSync > 3600000 || lastSync == 0) {
    syncTime();
    lastSync = millis();
  }
}`;

  const stmCode = `/*
  ========================================================================
  ⚙️ STM32 PROTOCOL REFERENCE (UART PARSER)
  ========================================================================
  Connect STM32 RX to ESP32 TX2 (Pin 17) and STM32 TX to ESP32 RX2 (Pin 16)
  Configure UART at Baud Rate: 9600, 8N1
  ========================================================================
*/

#include "main.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Simulated UART RX Buffer variables in STM32
char rx_buffer[100];
int rx_index = 0;

void Parse_ESP32_Command(char* cmd) {
    if (strncmp(cmd, "TIME:", 5) == 0) {
        // Format: TIME:HH:MM:SS:DD:MM:YYYY
        int hh, mm, ss, d, m, y;
        sscanf(cmd + 5, "%d:%d:%d:%d:%d:%d", &hh, &mm, &ss, &d, &m, &y);
        Set_RTC_Time(hh, mm, ss, d, m, y); // Set physical RTC chip
        
    } else if (strncmp(cmd, "BELL:", 5) == 0) {
        // Format: BELL:period:hour:minute:duration
        int period, hour, minute, duration;
        sscanf(cmd + 5, "%d:%d:%d:%d", &period, &hour, &minute, &duration);
        Save_Bell_Schedule_To_EEPROM(period, hour, minute, duration);
        
    } else if (strncmp(cmd, "HOLIDAY:", 8) == 0) {
        // Format: HOLIDAY:DD-MM-YYYY
        char date[12];
        strcpy(date, cmd + 8);
        Register_Holiday_In_Flash(date);
        
    } else if (strncmp(cmd, "MANUAL:", 7) == 0) {
        // Format: MANUAL:ON or MANUAL:OFF
        if (strstr(cmd, "ON") != NULL) {
            Trigger_Relay(1); // Turn physical relay pin HIGH
        } else {
            Trigger_Relay(0); // Turn physical relay pin LOW
        }
    }
}
`;

  const copyToClipboard = (text: string, isStm: boolean) => {
    navigator.clipboard.writeText(text);
    if (isStm) {
      setCopiedStm(true);
      setTimeout(() => setCopiedStm(false), 2000);
    } else {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6" id="firmware-guide-section">
      
      {/* Language Bar & Header */}
      <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="font-bold text-white text-base flex items-center gap-2 uppercase tracking-wider font-mono">
            <Terminal className="h-5 w-5 text-[#F27D26]" />
            Hardware & 3MB Optimized Firmware Guide
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            {language === 'hinglish' 
              ? 'ESP32 की मेमोरी बढ़ाने, लाइट जाने के बाद भी डेटा सुरक्षित रखने और 3MB साइज के लिए अनुकूलित कोड'
              : 'Optimized ESP32 memory footprint, power-cut backup, and 3MB partition compilation instructions'
            }
          </p>
        </div>

        <div className="bg-[#0F1115] p-1 rounded-lg flex text-xs font-bold border border-[#2A2D35] self-start sm:self-center">
          <button
            onClick={() => setLanguage('hinglish')}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer ${language === 'hinglish' ? 'bg-[#F27D26] text-white shadow-md' : 'text-gray-400 hover:text-white'}`}
          >
            Hinglish (हिंदी)
          </button>
          <button
            onClick={() => setLanguage('english')}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer ${language === 'english' ? 'bg-[#F27D26] text-white shadow-md' : 'text-gray-400 hover:text-white'}`}
          >
            English
          </button>
        </div>
      </div>

      {/* 🟢 CRITICAL SIZE OPTIMIZATION TIPS CARD (3MB CONFIGURE GUIDE) */}
      <div className="bg-gradient-to-r from-amber-500/10 to-[#F27D26]/5 border border-amber-500/20 rounded-3xl p-5 text-left text-xs leading-relaxed text-gray-300 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex gap-4 items-start">
          <div className="p-3 bg-[#F27D26]/10 text-[#F27D26] rounded-2xl border border-[#F27D26]/20 shrink-0">
            <HardDrive className="h-6 w-6 text-[#F27D26] animate-pulse" />
          </div>
          <div>
            <h4 className="font-extrabold text-white text-sm uppercase tracking-wider mb-2 flex items-center gap-1.5 font-mono">
              <Cpu className="h-4 w-4 text-[#F27D26]" />
              {language === 'hinglish' ? 'ESP32 मेमोरी 3MB सेट करने की सीक्रेट गाइड!' : 'ESP32 3MB Partition Configuration Guide'}
            </h4>
            
            {language === 'hinglish' ? (
              <div className="space-y-2">
                <p>
                  जब आप ESP32 पर वाई-फाई और वेबसर्वर लाइब्रेरीज़ के साथ कोड कंपाइल करते हैं, तो कभी-कभी डिफ़ॉल्ट रूप से Arduino IDE में <strong>"Sketch too big"</strong> एरर आता है क्योंकि डिफ़ॉल्ट ऐप लिमिट केवल 1.2MB होती है। 
                  इसे बिना किसी समस्या के <strong>3MB साइज</strong> तक बढ़ाने के लिए Arduino IDE में यह सेटिंग्स जरूर करें:
                </p>
                <div className="bg-[#0F1115] border border-[#2A2D35] p-3.5 rounded-xl space-y-1.5 font-mono text-[11px] text-amber-400 mt-2">
                  <div>1. ऊपर मेनू में जाएँ: <strong className="text-white">Tools (टूल्स) ➔ Board (बोर्ड)</strong> ➔ अपना ESP32 बोर्ड चुनें।</div>
                  <div>2. फिर जाएँ: <strong className="text-white">Tools ➔ Partition Scheme (पार्टीशन स्कीम)</strong>।</div>
                  <div>3. वहाँ <strong className="text-white">"Huge APP (3MB No OTA / 1MB SPIFFS)"</strong> या <strong className="text-white">"No OTA (Large APP)"</strong> पर क्लिक करें।</div>
                  <div className="text-gray-400 mt-1 italic">// यह करने से आपके ESP32 का कंपाइलर साइज लिमिट तुरंत 3MB (3145728 bytes) हो जाएगा और कोड आसानी से कंपाइल होगा!</div>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <p>
                  When compiling ESP32 projects with WiFi and Web Server features, the compiled sketch can occasionally exceed the default 1.2MB flash boundary. 
                  To safely unlock the full **3MB Flash compiler memory**, apply this quick setting inside your Arduino IDE:
                </p>
                <div className="bg-[#0F1115] border border-[#2A2D35] p-3.5 rounded-xl space-y-1.5 font-mono text-[11px] text-amber-400 mt-2">
                  <div>1. Go to: <strong className="text-white">Tools ➔ Board</strong> ➔ Select your ESP32 model.</div>
                  <div>2. Click on: <strong className="text-white">Tools ➔ Partition Scheme</strong>.</div>
                  <div>3. Choose <strong className="text-white">"Huge APP (3MB No OTA / 1MB SPIFFS)"</strong> or <strong className="text-white">"No OTA (Large APP)"</strong>.</div>
                  <div className="text-gray-400 mt-1 italic">// This instantly allocates up to 3MB (3,145,728 bytes) of flash storage space for your compiled binary!</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Pin Connections & Overview Block */}
      <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-[#F27D26]/5 rounded-full blur-3xl pointer-events-none" />
        
        <h3 className="font-bold text-sm flex items-center gap-2 uppercase tracking-wider font-mono">
          <Terminal className="h-5 w-5 text-[#F27D26]" />
          Physical Connections
        </h3>

        {/* Pin Connections Grid */}
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[#0F1115] p-4 rounded-xl border border-[#2A2D35] text-left">
            <span className="text-[10px] text-[#F27D26] font-bold uppercase tracking-wider block mb-1 font-mono">Pin Mapping</span>
            <h4 className="font-semibold text-xs text-gray-200">ESP32 ⇄ STM32</h4>
            <div className="mt-3 space-y-1.5 text-xs text-gray-400 font-mono">
              <div className="flex justify-between border-b border-[#2A2D35] pb-1.5">
                <span>ESP32 Pin 17 (TX2)</span>
                <span className="text-white">➔ STM32 RX</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2D35] pb-1.5">
                <span>ESP32 Pin 16 (RX2)</span>
                <span className="text-white">➔ STM32 TX</span>
              </div>
              <div className="flex justify-between">
                <span>ESP32 GND</span>
                <span className="text-white">➔ Common GND</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0F1115] p-4 rounded-xl border border-[#2A2D35] text-left">
            <span className="text-[10px] text-[#00FF9C] font-bold uppercase tracking-wider block mb-1 font-mono">3MB Code Optimization</span>
            <h4 className="font-semibold text-xs text-gray-200">What we optimized:</h4>
            <p className="text-xs text-gray-400 mt-2 leading-relaxed font-sans">
              We replaced complex String buffers with efficient memory layout, used direct <code className="text-[#00FF9C]">Serial2.printf</code> to bypass double allocations, and removed bulky comments to drastically shrink the compile size!
            </p>
          </div>

          <div className="bg-[#0F1115] p-4 rounded-xl border border-[#2A2D35] text-left">
            <span className="text-[10px] text-[#F27D26] font-bold uppercase tracking-wider block mb-1 font-mono">Power Cut Protection</span>
            <h4 className="font-semibold text-xs text-gray-200">Preferences Memory</h4>
            <p className="text-xs text-gray-400 mt-2 leading-relaxed font-sans">
              All settings are safely backed up inside non-volatile EEPROM/Preferences sector. If light/power gets cut, the ESP32 automatically re-injects schedules to STM32.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* ESP32 Upgraded C++ Code */}
        <div className="lg:col-span-8 space-y-3">
          <div className="flex justify-between items-center px-4">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5 font-mono">
              <Zap className="h-3.5 w-3.5 text-[#F27D26]" />
              1. Super Optimized ESP32 Arduino C++ Code
            </span>
            <button
              onClick={() => copyToClipboard(espCode, false)}
              className="bg-[#15181F] hover:bg-[#1A1D24] text-gray-300 hover:text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all border border-[#2A2D35] shadow-sm cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-[#00FF9C]" /> {language === 'hinglish' ? 'कॉपी हो गया!' : 'Copied!'}
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5 text-[#F27D26]" /> Copy ESP32 Code
                </>
              )}
            </button>
          </div>

          <div className="bg-[#0F1115] rounded-2xl overflow-hidden border border-[#2A2D35] text-left relative">
            <pre className="p-5 overflow-auto text-xs font-mono text-gray-300 leading-relaxed max-h-[500px]">
              {espCode}
            </pre>
          </div>
        </div>

        {/* STM32 Protocol Reference */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex justify-between items-center px-4">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider font-mono">
              2. STM32 Protocol Reference
            </span>
            <button
              onClick={() => copyToClipboard(stmCode, true)}
              className="text-gray-400 hover:text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
            >
              {copiedStm ? <Check className="h-3.5 w-3.5 text-[#00FF9C]" /> : <Copy className="h-3.5 w-3.5 text-[#F27D26]" />}
            </button>
          </div>

          <div className="bg-[#0F1115] rounded-2xl p-5 overflow-hidden border border-[#2A2D35] text-left text-xs font-mono text-gray-400 space-y-4 max-h-[500px] overflow-y-auto">
            <div className="bg-[#1A1D24] p-3 rounded-lg border border-[#2A2D35] text-gray-300 font-sans text-xs">
              <strong className="text-[#F27D26] font-mono uppercase tracking-wider text-[10px] block mb-1">💡 STM32 Instructions:</strong>
              यह कोड दर्शाता है कि STM32 कैसे ESP32 द्वारा भेजे गए सीरियल डेटा को पार्स (Read) करके अपनी घंटी बजाता है और समय सिंक करता है।
            </div>
            <pre className="leading-relaxed text-gray-300">
              {stmCode}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
