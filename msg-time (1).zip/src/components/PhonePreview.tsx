import React, { useState } from 'react';
import { Smartphone, RefreshCw, Send, CheckCircle, AlertCircle, Calendar, Wifi, Bell, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BellPeriod, Holiday } from '../types';

interface PhonePreviewProps {
  periods: BellPeriod[];
  setPeriods: React.Dispatch<React.SetStateAction<BellPeriod[]>>;
  holidays: Holiday[];
  setHolidays: React.Dispatch<React.SetStateAction<Holiday[]>>;
  addLog: (type: 'ESP32' | 'STM32' | 'APP' | 'SYSTEM', message: string, isCommand?: boolean) => void;
  espIp: string;
}

export default function PhonePreview({
  periods,
  setPeriods,
  holidays,
  setHolidays,
  addLog,
  espIp
}: PhonePreviewProps) {
  // Local phone state
  const [selectedPeriod, setSelectedPeriod] = useState<number>(1);
  const [phoneHour, setPhoneHour] = useState<string>('09');
  const [phoneMinute, setPhoneMinute] = useState<string>('30');
  const [phoneDuration, setPhoneDuration] = useState<string>('10');
  
  const [phoneHolidayDate, setPhoneHolidayDate] = useState<string>('26-01-2027');
  const [phoneHolidayLabel, setPhoneHolidayLabel] = useState<string>('Republic Day');

  const [connectionStatus, setConnectionStatus] = useState<'Disconnected' | 'Scanning' | 'Connected'>('Connected');
  const [discoveredIp, setDiscoveredIp] = useState<string>('schoolbell.local');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const triggerScan = () => {
    setConnectionStatus('Scanning');
    setDiscoveredIp('Scanning subnet 192.168.1.X...');
    addLog('APP', 'Auto IP Discovery scan initiated from Android device.');
    
    let counter = 1;
    const interval = setInterval(() => {
      counter += 25;
      if (counter >= 254) {
        clearInterval(interval);
        setConnectionStatus('Connected');
        setDiscoveredIp('192.168.1.50'); // Lock to simulated IP
        addLog('APP', 'Auto IP Discovery completed. Connected to ESP32 at: 192.168.1.50');
        showToast('ESP32 Bell Found at: 192.168.1.50!');
      }
    }, 150);
  };

  const handlePhoneUpdate = () => {
    const pId = selectedPeriod;
    const h = parseInt(phoneHour) || 0;
    const m = parseInt(phoneMinute) || 0;
    const d = parseInt(phoneDuration) || 5;

    const targetUrl = `http://${discoveredIp}/updateBell?period=${pId}&hour=${h}&minute=${m}&duration=${d}`;
    addLog('APP', `[Mobile App] Dispatched HTTP GET: ${targetUrl}`);
    addLog('ESP32', `Received Remote Bell Sync Request: Period ${pId} scheduled at ${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')} for ${d}s`);
    
    // Update global list
    setPeriods(prev => prev.map(p => p.id === pId ? { ...p, hour: h, minute: m, duration: d } : p));
    showToast(`Period ${pId} Updated successfully!`);
  };

  const handlePhoneAddHoliday = () => {
    if (!phoneHolidayDate) return;
    const targetUrl = `http://${discoveredIp}/addHoliday?date=${phoneHolidayDate}`;
    addLog('APP', `[Mobile App] Dispatched Holiday HTTP GET: ${targetUrl}`);
    addLog('ESP32', `Received Remote Holiday addition: ${phoneHolidayDate} (${phoneHolidayLabel})`);
    
    const newHoliday: Holiday = {
      id: Math.random().toString(),
      date: phoneHolidayDate,
      label: phoneHolidayLabel
    };
    setHolidays(prev => [...prev, newHoliday]);
    showToast(`Holiday Added for ${phoneHolidayDate}!`);
  };

  const handlePhoneManualBell = (status: boolean) => {
    const statusStr = status ? 'ON' : 'OFF';
    const targetUrl = `http://${discoveredIp}/manualBell?status=${statusStr}`;
    addLog('APP', `[Mobile App] Dispatched Manual Bell: ${targetUrl}`);
    addLog('ESP32', `Manual Bell remote trigger: ${statusStr}`);
    addLog('STM32', `Relay signal set: ${statusStr === 'ON' ? '🔔 RINGING' : '🔕 SILENT'}`, true);
    showToast(`Manual Bell turned ${statusStr}!`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start py-4" id="phone-preview-section">
      
      {/* Visual Device Frame Wrapper */}
      <div className="lg:col-span-5 flex justify-center">
        <div className="relative mx-auto border-[#2A2D35] bg-[#0F1115] border-[14px] rounded-[2.5rem] h-[720px] w-[360px] shadow-2xl flex flex-col overflow-hidden">
          {/* Phone Speaker Notch */}
          <div className="absolute top-0 inset-x-0 h-4 bg-[#0F1115] z-50 flex justify-center">
            <div className="w-24 h-3 bg-black rounded-b-xl" />
          </div>

          {/* Status Bar */}
          <div className="bg-[#1A1D24] text-gray-400 px-6 pt-5 pb-1 flex justify-between items-center text-[10px] font-bold font-mono select-none border-b border-[#2A2D35]">
            <span>02:21 PM</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px]">4G LTE</span>
              <Wifi className="h-3 w-3 text-[#00FF9C]" />
              <span className="h-3.5 w-6 bg-white/10 rounded border border-white/10 relative flex items-center px-0.5">
                <span className="h-full w-[80%] bg-[#00FF9C] rounded-sm" />
              </span>
            </div>
          </div>

          {/* Screen Content Wrapper */}
          <div className="flex-grow bg-[#0F1115] flex flex-col text-gray-200 relative">
            
            {/* Header branding */}
            <div className="bg-[#1A1D24] text-white px-4 py-3.5 border-b border-[#3c3a9a] flex justify-between items-center">
              <div>
                <h3 className="font-bold text-xs tracking-wider font-mono text-[#e07171]">🏫 AUTOMATIC BELL</h3>
                <span className="text-[8px] text-[#F27D26] uppercase block font-mono font-bold tracking-widest">School & College Edition</span>
              </div>
              <span className="bg-[#F27D26]/10 p-1.5 rounded-lg border border-[#F27D26]/20">
                <Bell className="h-3.5 w-3.5 text-[#F27D26] animate-bounce" />
              </span>
            </div>

            {/* Simulated App Screen Area */}
            <div className="flex-grow overflow-y-auto p-4 space-y-4 text-xs border border-[#37599a] bg-[#1b3c7d]">
              
              {/* Connection Status Card */}
              <div className="bg-[#1A1D24] p-3 rounded-xl border border-[#2A2D35] shadow-md space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider font-mono">Device Connection</span>
                  <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold uppercase font-mono ${
                    connectionStatus === 'Connected' ? 'bg-[#00FF9C]/10 text-[#00FF9C] border border-[#00FF9C]/20' :
                    connectionStatus === 'Scanning' ? 'bg-[#F27D26]/10 text-[#F27D26] border border-[#F27D26]/20 animate-pulse' :
                    'bg-gray-800 text-gray-400'
                  }`}>
                    ● {connectionStatus}
                  </span>
                </div>
                
                <div className="flex items-center justify-between gap-1 bg-[#0F1115] p-2 rounded-lg border border-[#2A2D35]">
                  <span className="font-mono text-[10px] text-gray-300 truncate max-w-[160px] font-bold">
                    {discoveredIp}
                  </span>
                  <button 
                    onClick={triggerScan}
                    className="bg-[#F27D26] hover:bg-[#d66b1d] text-white px-2 py-1 rounded text-[9px] font-bold font-mono flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <RefreshCw className="h-2.5 w-2.5" /> Auto Assign IP
                  </button>
                </div>
              </div>

              {/* Update Schedule Form */}
              <div className="bg-[#1A1D24] p-3.5 rounded-xl border border-[#2A2D35] shadow-md space-y-3 text-left">
                <h4 className="font-bold text-[10px] text-white uppercase tracking-wider font-mono border-b border-[#2A2D35] pb-1.5 flex items-center gap-1">
                  ⏰ Update Bell Times
                </h4>

                <div className="space-y-2">
                  <div>
                    <label className="text-[9px] font-bold font-mono text-gray-400 block mb-0.5">Select Period</label>
                    <select 
                      value={selectedPeriod}
                      onChange={(e) => {
                        const pId = parseInt(e.target.value);
                        setSelectedPeriod(pId);
                        const match = periods.find(p => p.id === pId);
                        if (match) {
                          setPhoneHour(String(match.hour).padStart(2, '0'));
                          setPhoneMinute(String(match.minute).padStart(2, '0'));
                          setPhoneDuration(String(match.duration));
                        }
                      }}
                      className="w-full border border-[#2A2D35] rounded p-1 text-[11px] bg-[#0F1115] text-white font-mono font-medium focus:outline-none focus:border-[#F27D26]"
                    >
                      {periods.map(p => (
                        <option key={p.id} value={p.id} className="bg-[#1A1D24] text-white">Period {p.id} ({p.periodName})</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-3 gap-1.5 font-mono">
                    <div>
                      <label className="text-[9px] font-bold text-gray-400 block mb-0.5">Hour (24h)</label>
                      <input 
                        type="number" 
                        value={phoneHour}
                        onChange={(e) => setPhoneHour(e.target.value)}
                        className="w-full border border-[#2A2D35] rounded p-1 text-[11px] text-center font-bold text-white bg-[#0F1115] focus:outline-none focus:border-[#F27D26]"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-gray-400 block mb-0.5">Minute</label>
                      <input 
                        type="number" 
                        value={phoneMinute}
                        onChange={(e) => setPhoneMinute(e.target.value)}
                        className="w-full border border-[#2A2D35] rounded p-1 text-[11px] text-center font-bold text-white bg-[#0F1115] focus:outline-none focus:border-[#F27D26]"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-gray-400 block mb-0.5">Sec Dur</label>
                      <input 
                        type="number" 
                        value={phoneDuration}
                        onChange={(e) => setPhoneDuration(e.target.value)}
                        className="w-full border border-[#2A2D35] rounded p-1 text-[11px] text-center font-bold text-white bg-[#0F1115] focus:outline-none focus:border-[#F27D26]"
                      />
                    </div>
                  </div>

                  <button
                    onClick={handlePhoneUpdate}
                    className="w-full bg-[#F27D26] hover:bg-[#d66b1d] text-white font-bold py-1.5 rounded text-[10px] font-mono flex items-center justify-center gap-1 mt-1 transition-colors cursor-pointer uppercase tracking-wider"
                  >
                    <Send className="h-3 w-3" /> Save & Update Bell
                  </button>
                </div>
              </div>

              {/* Add Holiday Card */}
              <div className="bg-[#1A1D24] p-3.5 rounded-xl border border-[#2A2D35] shadow-md space-y-3 text-left">
                <h4 className="font-bold text-[10px] text-white uppercase tracking-wider font-mono border-b border-[#2A2D35] pb-1.5 flex items-center gap-1">
                  📅 Add Holiday (Off Day)
                </h4>

                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-1.5 font-mono">
                    <div>
                      <label className="text-[9px] font-bold text-gray-400 block mb-0.5">Date</label>
                      <input 
                        type="text" 
                        placeholder="DD-MM-YYYY"
                        value={phoneHolidayDate}
                        onChange={(e) => setPhoneHolidayDate(e.target.value)}
                        className="w-full border border-[#2A2D35] rounded p-1 text-[10px] text-white bg-[#0F1115] focus:outline-none focus:border-[#F27D26]"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-gray-400 block mb-0.5">Label</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Sunday"
                        value={phoneHolidayLabel}
                        onChange={(e) => setPhoneHolidayLabel(e.target.value)}
                        className="w-full border border-[#2A2D35] rounded p-1 text-[10px] text-white bg-[#0F1115] focus:outline-none focus:border-[#F27D26]"
                      />
                    </div>
                  </div>

                  <button
                    onClick={handlePhoneAddHoliday}
                    className="w-full bg-[#00FF9C] hover:bg-[#00e089] text-[#0F1115] font-extrabold py-1.5 rounded text-[10px] font-mono flex items-center justify-center gap-1 transition-colors cursor-pointer uppercase tracking-wider"
                  >
                    <Calendar className="h-3 w-3" /> Register Holiday
                  </button>
                </div>
              </div>

              {/* Manual Trigger Buttons */}
              <div className="bg-[#1A1D24] p-3.5 rounded-xl border border-[#2A2D35] shadow-md text-left space-y-3">
                <h4 className="font-bold text-[10px] text-white uppercase tracking-wider font-mono border-b border-[#2A2D35] pb-1.5">
                  ⚡ Manual Bell ON / OFF
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handlePhoneManualBell(true)}
                    className="bg-rose-600 hover:bg-rose-700 text-white font-bold py-2 rounded-lg text-[10px] font-mono flex items-center justify-center gap-1 shadow-sm transition-all active:scale-95 cursor-pointer uppercase tracking-wider"
                  >
                    <Bell className="h-3 w-3" /> Turn ON
                  </button>
                  <button
                    onClick={() => handlePhoneManualBell(false)}
                    className="bg-[#0F1115] hover:bg-[#15181F] border border-[#2A2D35] text-gray-400 hover:text-white font-bold py-2 rounded-lg text-[10px] font-mono flex items-center justify-center gap-1 shadow-sm transition-all active:scale-95 cursor-pointer uppercase tracking-wider"
                  >
                    🔕 Turn OFF
                  </button>
                </div>
              </div>

            </div>

            {/* In-App Interactive Toast */}
            <AnimatePresence>
              {toastMessage && (
                <motion.div
                  initial={{ opacity: 0, y: 50, scale: 0.9 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 50, scale: 0.9 }}
                  className="absolute bottom-16 inset-x-4 bg-[#1A1D24]/95 backdrop-blur-md text-white px-3 py-2.5 rounded-lg text-[10px] font-bold flex items-center gap-1.5 shadow-2xl border border-[#2A2D35] z-50 justify-center text-center font-mono"
                >
                  <CheckCircle className="h-3.5 w-3.5 text-[#00FF9C] shrink-0" />
                  <span>{toastMessage}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Android Navigation Bar */}
            <div className="bg-black py-2.5 flex justify-around items-center select-none border-t border-[#2A2D35]/40">
              <div className="w-3.5 h-3.5 border-2 border-white/40 rounded-sm" />
              <div className="w-4 h-4 border-2 border-white/40 rounded-full" />
              <div className="w-0 h-0 border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent border-r-[10px] border-r-white/40" />
            </div>

          </div>
        </div>
      </div>

      {/* Side Explanations Guide Column */}
      <div className="lg:col-span-7 space-y-6 text-left">
        <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#2A2D35]">
            <span className="p-1.5 bg-[#F27D26]/10 text-[#F27D26] rounded-lg border border-[#F27D26]/20">
              <Smartphone className="h-5 w-5" />
            </span>
            <h3 className="font-bold text-white text-base uppercase tracking-wider font-mono">Interactive App Simulator Details</h3>
          </div>

          <p className="text-xs text-gray-400 leading-relaxed">
            यह मोबाइल फ्रेम आपके द्वारा **MIT App Inventor** में बनाए जाने वाले Android App का सजीव प्रदर्शन (Live Mockup) है। 
            यहाँ किसी भी बटन को दबाने से, आपके ESP32 का वर्चुअल सर्वर लाइव डेटा अपडेट प्राप्त करता है।
          </p>

          <div className="bg-[#F27D26]/5 p-4 rounded-xl border border-[#F27D26]/20 space-y-3 text-xs text-gray-300 leading-relaxed">
            <h4 className="font-bold flex items-center gap-1.5 text-[#F27D26] font-mono uppercase tracking-wider text-[11px]">
              <ShieldCheck className="h-4 w-4 text-[#00FF9C]" />
              How to verify connection:
            </h4>
            <ul className="space-y-2 list-disc list-inside text-gray-300">
              <li><strong>Auto Assign IP Button:</strong> This triggers a mock subnet scan (checking <code>192.168.1.1</code> to <code>192.168.1.254</code>). When it succeeds, it sets the App address to the found IP.</li>
              <li><strong>Dynamic variables:</strong> If you use the mDNS method (Method 1), the App simply keeps targeting <code>schoolbell.local</code> without scanning!</li>
            </ul>
          </div>

          <div className="border border-[#2A2D35] rounded-xl p-4 bg-[#0F1115] space-y-3">
            <h4 className="font-bold text-xs text-white uppercase tracking-wider font-mono">App Designer Layout Components Mapping:</h4>
            
            <div className="grid grid-cols-2 gap-3 text-[10px] font-mono text-gray-300">
              <div className="p-2.5 bg-[#1A1D24] border border-[#2A2D35] rounded-lg">
                <span className="text-[9px] text-[#F27D26] font-bold block uppercase tracking-wider mb-1">Visual List / Spin</span>
                <span className="text-white font-bold">ListPicker_Period</span>
                <span className="text-[9px] text-gray-400 block mt-1 leading-normal">Selects Period ID (1-12)</span>
              </div>

              <div className="p-2.5 bg-[#1A1D24] border border-[#2A2D35] rounded-lg">
                <span className="text-[9px] text-[#F27D26] font-bold block uppercase tracking-wider mb-1">Numeric Inputs</span>
                <span className="text-white font-bold">TextBox_Hour / TextBox_Minute</span>
                <span className="text-[9px] text-gray-400 block mt-1 leading-normal">Keypad set to NumbersOnly</span>
              </div>

              <div className="p-2.5 bg-[#1A1D24] border border-[#2A2D35] rounded-lg">
                <span className="text-[9px] text-[#F27D26] font-bold block uppercase tracking-wider mb-1">Trigger Actions</span>
                <span className="text-white font-bold">Button_SaveUpdate</span>
                <span className="text-[9px] text-gray-400 block mt-1 leading-normal">Sends command to ESP32</span>
              </div>

              <div className="p-2.5 bg-[#1A1D24] border border-[#2A2D35] rounded-lg">
                <span className="text-[9px] text-[#F27D26] font-bold block uppercase tracking-wider mb-1">Manual Control</span>
                <span className="text-white font-bold">Button_BellON / Button_BellOFF</span>
                <span className="text-[9px] text-gray-400 block mt-1 leading-normal">Triggers manual override relay</span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
