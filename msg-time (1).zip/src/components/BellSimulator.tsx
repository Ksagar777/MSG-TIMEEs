import React, { useState, useEffect, useRef } from 'react';
import { BellPeriod, SystemLog, Holiday } from '../types';
import { Play, Square, Bell, Plus, Trash2, Send, Clock, HelpCircle, Server, RefreshCw, Cpu, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface BellSimulatorProps {
  periods: BellPeriod[];
  setPeriods: React.Dispatch<React.SetStateAction<BellPeriod[]>>;
  holidays: Holiday[];
  setHolidays: React.Dispatch<React.SetStateAction<Holiday[]>>;
  logs: SystemLog[];
  addLog: (type: 'ESP32' | 'STM32' | 'APP' | 'SYSTEM', message: string, isCommand?: boolean) => void;
  clearLogs: () => void;
  espIp: string;
  isMdnsEnabled: boolean;
}

export default function BellSimulator({
  periods,
  setPeriods,
  holidays,
  setHolidays,
  logs,
  addLog,
  clearLogs,
  espIp,
  isMdnsEnabled
}: BellSimulatorProps) {
  const [activeTab, setActiveTab] = useState<'grid' | 'modern'>('grid');
  const [isSimulationRunning, setIsSimulationRunning] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [simSpeed, setSimSpeed] = useState<1 | 60 | 3600>(1); // Realtime, 1m/s, 1h/s
  const [bellRinging, setBellRinging] = useState(false);
  const [ringingPeriod, setRingingPeriod] = useState<string | null>(null);
  
  // Input fields for adding items
  const [selectedPeriodId, setSelectedPeriodId] = useState<number>(1);
  const [inputHour, setInputHour] = useState<string>('08');
  const [inputMinute, setInputMinute] = useState<string>('00');
  const [inputDuration, setInputDuration] = useState<string>('5');
  
  const [holidayDate, setHolidayDate] = useState<string>('15-08-2026');
  const [holidayLabel, setHolidayLabel] = useState<string>('Independence Day');
  
  const [manualBellState, setManualBellState] = useState<boolean>(false);
  const [lastApiUrl, setLastApiUrl] = useState<string>('');
  const [lastSerialCmd, setLastSerialCmd] = useState<string>('');

  // Clock management
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isSimulationRunning) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          const next = new Date(prev.getTime() + 1000 * simSpeed);
          
          // Check if it's a new minute/second and matches a bell
          const currentHour = next.getHours();
          const currentMin = next.getMinutes();
          const currentSec = next.getSeconds();
          
          // Only check match on second 0 of real/simulated time to trigger bell
          if (currentSec === 0 || simSpeed > 1) {
            // Format current date for holiday checking
            const dayStr = String(next.getDate()).padStart(2, '0');
            const monthStr = String(next.getMonth() + 1).padStart(2, '0');
            const yearStr = next.getFullYear();
            const formattedDate = `${dayStr}-${monthStr}-${yearStr}`;
            
            const isHoliday = holidays.some(h => h.date === formattedDate);
            
            if (isHoliday) {
              // Holiday checking logic
              const matchingPeriod = periods.find(p => p.hour === currentHour && p.minute === currentMin);
              if (matchingPeriod) {
                addLog('SYSTEM', `Bell for Period ${matchingPeriod.id} suppressed because today (${formattedDate}) is a Holiday!`);
              }
            } else {
              const matchingPeriod = periods.find(p => p.hour === currentHour && p.minute === currentMin);
              if (matchingPeriod && !bellRinging) {
                triggerBell(matchingPeriod);
              }
            }
          }
          
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isSimulationRunning, simSpeed, periods, holidays, bellRinging]);

  const triggerBell = (period: BellPeriod) => {
    setBellRinging(true);
    setRingingPeriod(`Period ${period.id}`);
    addLog('STM32', `🔔 Automatic Bell Ringing! Period: ${period.id}, Duration: ${period.duration}s`);
    
    setTimeout(() => {
      setBellRinging(false);
      setRingingPeriod(null);
      addLog('STM32', `🔕 Bell Finished Ringing for Period ${period.id}`);
    }, period.duration * 1000);
  };

  // Handlers matching ESP32 endpoints
  const handleUpdateBellSim = (pId: number, h: number, m: number, dur: number) => {
    const targetUrl = `http://${espIp}/updateBell?period=${pId}&hour=${h}&minute=${m}&duration=${dur}`;
    const serialCmd = `BELL:${pId}:${h}:${m}:${dur}`;
    
    setLastApiUrl(targetUrl);
    setLastSerialCmd(serialCmd);
    
    // Update local periods
    setPeriods(prev => prev.map(p => p.id === pId ? { ...p, hour: h, minute: m, duration: dur } : p));
    
    addLog('APP', `HTTP GET -> ${targetUrl}`);
    addLog('ESP32', `Received Bell Update: Period ${pId} -> ${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}, Dur: ${dur}s`);
    addLog('ESP32', `Forwarding to STM32: ${serialCmd}`, true);
    addLog('STM32', `Acknowledge: Period ${pId} scheduled.`);
  };

  const handleAddHolidaySim = (dateStr: string, labelStr: string) => {
    const targetUrl = `http://${espIp}/addHoliday?date=${dateStr}`;
    const serialCmd = `HOLIDAY:${dateStr}`;
    
    setLastApiUrl(targetUrl);
    setLastSerialCmd(serialCmd);
    
    const newHoliday: Holiday = {
      id: Math.random().toString(),
      date: dateStr,
      label: labelStr
    };
    
    setHolidays(prev => [...prev, newHoliday]);
    
    addLog('APP', `HTTP GET -> ${targetUrl}`);
    addLog('ESP32', `Received Holiday Addition: ${dateStr} (${labelStr})`);
    addLog('ESP32', `Forwarding to STM32: ${serialCmd}`, true);
    addLog('STM32', `Acknowledge Holiday: ${dateStr}. Bell operations will be disabled on this date.`);
  };

  const handleManualBellSim = (status: boolean) => {
    const statusStr = status ? 'ON' : 'OFF';
    const targetUrl = `http://${espIp}/manualBell?status=${statusStr}`;
    const serialCmd = `MANUAL:${statusStr}`;
    
    setLastApiUrl(targetUrl);
    setLastSerialCmd(serialCmd);
    setManualBellState(status);
    
    addLog('APP', `HTTP GET -> ${targetUrl}`);
    addLog('ESP32', `Received Manual Bell Command: ${statusStr}`);
    addLog('ESP32', `Forwarding to STM32: ${serialCmd}`, true);
    
    if (status) {
      setBellRinging(true);
      setRingingPeriod('Manual Ring');
      addLog('STM32', `🔔 Manual Bell Started Ringing!`);
    } else {
      setBellRinging(false);
      setRingingPeriod(null);
      addLog('STM32', `🔕 Manual Bell Stopped Ringing!`);
    }
  };

  const handleNtpSyncSim = () => {
    const next = new Date();
    setCurrentTime(next);
    
    // Send time packet: TIME:HH:MM:SS:DD:MM:YYYY
    const hourStr = String(next.getHours()).padStart(2, '0');
    const minStr = String(next.getMinutes()).padStart(2, '0');
    const secStr = String(next.getSeconds()).padStart(2, '0');
    const dayStr = String(next.getDate()).padStart(2, '0');
    const monthStr = String(next.getMonth() + 1).padStart(2, '0');
    const yearStr = next.getFullYear();
    
    const timeStr = `TIME:${hourStr}:${minStr}:${secStr}:${dayStr}:${monthStr}:${yearStr}`;
    
    addLog('SYSTEM', 'NTP Server Pool Sync Triggered');
    addLog('ESP32', `Syncing Internet Time: ${timeStr}`);
    addLog('ESP32', `Auto-Correct Signal Sent over Serial2`, true);
    addLog('STM32', `RTC Time Synchronized to: ${hourStr}:${minStr}:${secStr}`);
  };

  const deleteHoliday = (id: string) => {
    const h = holidays.find(item => item.id === id);
    if (h) {
      setHolidays(prev => prev.filter(item => item.id !== id));
      addLog('SYSTEM', `Holiday removed: ${h.date}`);
    }
  };

  // Convert current simulated time to human string
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-GB').replace(/\//g, '-'); // DD-MM-YYYY
  };

  return (
    <div className="space-y-6" id="bell-simulator-section">
      {/* Simulation Master Controller */}
      <div className="bg-[#040e1e] border border-[#2A2D35] rounded-2xl p-4 text-[#E0E0E0] shadow-xl flex flex-wrap gap-4 items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#F27D26]/10 text-[#F27D26] rounded-lg border border-[#F27D26]/20">
            <Cpu className="h-6 w-6 animate-pulse" />
          </div>
          <div>
            <h3 className="font-semibold text-sm text-gray-400">ESP32 + STM32 Hardware Simulator</h3>
            <div className="flex items-center gap-2">
              <span className={`inline-block h-2 w-2 rounded-full ${isSimulationRunning ? 'bg-[#00FF9C] animate-ping' : 'bg-rose-500'}`} />
              <span className="text-xs font-mono text-gray-300">
                IP Address: <span className="text-[#F27D26] font-bold font-mono">{espIp}</span> {isMdnsEnabled && <span className="text-[#00FF9C]">(mDNS Active)</span>}
              </span>
            </div>
          </div>
        </div>

        {/* Live Clock HUD */}
        <div className="flex items-center gap-4 bg-[#0F1115] px-4 py-2 rounded-xl border border-[#2A2D35]">
          <div className="text-right">
            <div className="text-[10px] text-gray-500 font-mono uppercase tracking-wider">Simulated NTP Clock</div>
            <div className="text-xl font-bold font-mono text-[#00FF9C] tracking-wider">
              {formatTime(currentTime)}
            </div>
            <div className="text-[10px] text-gray-400 font-mono">
              Date: {formatDate(currentTime)} (IST +5:30)
            </div>
          </div>
          <button 
            onClick={handleNtpSyncSim}
            title="Sync NTP Now" 
            className="p-1.5 hover:bg-[#1A1D24] text-gray-400 hover:text-white rounded-lg transition-colors border border-transparent hover:border-[#2A2D35] cursor-pointer"
          >
            <RefreshCw className="h-4 w-4 text-[#F27D26]" />
          </button>
        </div>

        {/* Speed Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsSimulationRunning(!isSimulationRunning)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              isSimulationRunning ? 'bg-amber-600 hover:bg-amber-500 text-white' : 'bg-[#00FF9C] hover:bg-[#00FF9C]/90 text-[#0F1115]'
            }`}
          >
            {isSimulationRunning ? (
              <>
                <Square className="h-3 w-3 fill-white" /> Pause Clock
              </>
            ) : (
              <>
                <Play className="h-3 w-3 fill-[#0F1115]" /> Start Clock
              </>
            )}
          </button>
          
          <div className="flex items-center gap-1 bg-[#0F1115] p-1 rounded-lg border border-[#2A2D35]">
            <button
              onClick={() => setSimSpeed(1)}
              className={`px-2 py-1 rounded text-xs font-mono font-bold cursor-pointer ${simSpeed === 1 ? 'bg-[#F27D26] text-white' : 'text-gray-400 hover:text-gray-200'}`}
            >
              1x
            </button>
            <button
              onClick={() => setSimSpeed(60)}
              className={`px-2 py-1 rounded text-xs font-mono font-bold cursor-pointer ${simSpeed === 60 ? 'bg-[#F27D26] text-white' : 'text-gray-400 hover:text-gray-200'}`}
              title="1 minute per second"
            >
              60x
            </button>
            <button
              onClick={() => setSimSpeed(3600)}
              className={`px-2 py-1 rounded text-xs font-mono font-bold cursor-pointer ${simSpeed === 3600 ? 'bg-[#F27D26] text-white' : 'text-gray-400 hover:text-gray-200'}`}
              title="1 hour per second"
            >
              3600x
            </button>
          </div>
        </div>
      </div>

      {/* Visual Ringing Banner */}
      <AnimatePresence>
        {bellRinging && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-[#F27D26] text-white font-bold p-4 rounded-xl flex items-center justify-between shadow-lg shadow-orange-950/20 border border-[#ff8a3d]"
          >
            <div className="flex items-center gap-3">
              <motion.div
                animate={{ rotate: [-15, 15, -15, 15, 0] }}
                transition={{ repeat: Infinity, duration: 0.5, ease: "easeInOut" }}
              >
                <Bell className="h-6 w-6 fill-white" />
              </motion.div>
              <div>
                <span className="text-xs uppercase tracking-wider text-orange-100 block font-mono">Bell Status: Ringing</span>
                <span className="text-lg">{ringingPeriod || 'Manual Trigger'} is Active!</span>
              </div>
            </div>
            <button
              onClick={() => handleManualBellSim(false)}
              className="bg-black text-[#00FF9C] px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-black/80 transition-colors cursor-pointer"
            >
              Force Mute (OFF)
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Spreadsheet Replicant Grid Card / Modern Switcher */}
        <div className="lg:col-span-2 bg-[#1A1D24] border border-[#2A2D35] rounded-2xl shadow-xl overflow-hidden flex flex-col">
          <div className="px-5 py-4 bg-[#15181F] border-b border-[#2A2D35] flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-[#00FF9C]" />
              <h2 className="font-bold text-sm uppercase tracking-wider text-white">School Bell Configuration & Grid Settings</h2>
            </div>
            <div className="flex bg-[#0F1115] p-1 rounded-lg text-xs border border-[#2A2D35]">
              <button
                onClick={() => setActiveTab('grid')}
                className={`px-3 py-1 rounded-md font-bold transition-colors cursor-pointer ${activeTab === 'grid' ? 'bg-[#F27D26] text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
              >
                Excel Grid Replicant
              </button>
              <button
                onClick={() => setActiveTab('modern')}
                className={`px-3 py-1 rounded-md font-bold transition-colors cursor-pointer ${activeTab === 'modern' ? 'bg-[#F27D26] text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
              >
                Modern Form Controller
              </button>
            </div>
          </div>

          <div className="p-5 flex-grow overflow-auto bg-[#071e3e]">
            {activeTab === 'grid' ? (
              <div className="space-y-4">
                <p className="text-xs text-gray-400 leading-relaxed italic">
                  * यह तालिका आपकी संलग्न फोटो (Excel Spreadsheet Layout) की हूबहू नकल है। यहाँ से आप सीधे घंटी का समय बदल सकते हैं जो ESP32 को फॉरवर्ड होगी।
                </p>
                
                {/* Excel Table */}
                <div className="border border-[#2A2D35] rounded-lg overflow-hidden font-mono text-sm shadow-inner bg-black/20">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-[#15181F] text-gray-300 border-b border-[#2A2D35] text-xs font-mono uppercase tracking-wider">
                        <th className="p-2 border-r border-[#2A2D35] w-16 text-center bg-black/20 text-[#F27D26] font-bold">Cell</th>
                        <th className="p-2 border-r border-[#2A2D35]">A (Period Name / Label)</th>
                        <th className="p-2 border-r border-[#2A2D35] w-28 text-center">B (Hour)</th>
                        <th className="p-2 border-r border-[#2A2D35] w-28 text-center">C (Minute)</th>
                        <th className="p-2 border-r border-[#2A2D35] w-32 text-center">D (Duration sec)</th>
                        <th className="p-2 text-center w-20">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* Sub-header row matching row 3 */}
                      <tr className="bg-[#00FF9C]/5 text-xs border-b border-[#2A2D35] font-mono">
                        <td className="p-2 text-center border-r border-[#2A2D35] font-bold bg-black/10 text-gray-500">R3</td>
                        <td className="p-2 border-r border-[#2A2D35] font-semibold text-gray-300">Date: {formatDate(currentTime)}</td>
                        <td className="p-2 border-r border-[#2A2D35]" colSpan={2}>
                          <span className="font-semibold text-[#00FF9C]">Clock NTP: Synchronized</span>
                        </td>
                        <td className="p-2 border-r border-[#2A2D35] text-gray-400">Offset: +19800s</td>
                        <td className="p-2 bg-black/10"></td>
                      </tr>
                      {/* Sub-header row matching row 4 */}
                      <tr className="bg-black/10 text-xs border-b border-[#2A2D35] font-mono">
                        <td className="p-2 text-center border-r border-[#2A2D35] font-bold bg-black/15 text-gray-500">R4</td>
                        <td className="p-2 border-r border-[#2A2D35] text-[#00FF9C] font-bold tracking-wider uppercase" colSpan={4}>TIME SETTING FOR BELL TIMES</td>
                        <td className="p-2 bg-black/10"></td>
                      </tr>

                      {/* Main Periods Rows 6-17 */}
                      {periods.map((period, index) => {
                        const rowNum = 6 + index;
                        return (
                          <tr key={period.id} className="border-b border-[#2A2D35] hover:bg-white/5 transition-colors">
                            <td className="p-2 text-center border-r border-[#2A2D35] font-bold bg-black/10 text-gray-400 font-mono">R{rowNum}</td>
                            <td className="p-2 border-r border-[#2A2D35] font-medium text-gray-200">
                              <span className="text-[10px] px-2 py-0.5 rounded bg-[#2A2D35] text-gray-300 mr-2 font-mono font-normal">P{period.id}</span>
                              {period.periodName}
                            </td>
                            <td className="p-1 border-r border-[#2A2D35]">
                              <input
                                type="number"
                                min="0"
                                max="23"
                                value={String(period.hour).padStart(2, '0')}
                                onChange={(e) => {
                                  const h = Math.min(23, Math.max(0, parseInt(e.target.value) || 0));
                                  setPeriods(prev => prev.map(p => p.id === period.id ? { ...p, hour: h } : p));
                                }}
                                className="w-full bg-transparent px-2 py-1 outline-none text-white focus:bg-[#252932] font-bold text-center font-mono"
                              />
                            </td>
                            <td className="p-1 border-r border-[#2A2D35]">
                              <input
                                type="number"
                                min="0"
                                max="59"
                                value={String(period.minute).padStart(2, '0')}
                                onChange={(e) => {
                                  const m = Math.min(59, Math.max(0, parseInt(e.target.value) || 0));
                                  setPeriods(prev => prev.map(p => p.id === period.id ? { ...p, minute: m } : p));
                                }}
                                className="w-full bg-transparent px-2 py-1 outline-none text-white focus:bg-[#252932] font-bold text-center font-mono"
                              />
                            </td>
                            <td className="p-1 border-r border-[#2A2D35]">
                              <input
                                type="number"
                                min="1"
                                max="60"
                                value={period.duration}
                                onChange={(e) => {
                                  const d = Math.min(60, Math.max(1, parseInt(e.target.value) || 5));
                                  setPeriods(prev => prev.map(p => p.id === period.id ? { ...p, duration: d } : p));
                                }}
                                className="w-full bg-transparent px-2 py-1 outline-none text-white focus:bg-[#252932] font-bold text-center font-mono"
                              />
                            </td>
                            <td className="p-1.5 text-center">
                              <button
                                onClick={() => handleUpdateBellSim(period.id, period.hour, period.minute, period.duration)}
                                className="bg-[#F27D26]/10 text-[#F27D26] hover:bg-[#F27D26] hover:text-white px-2.5 py-1 rounded text-xs font-bold font-sans transition-all flex items-center gap-1 mx-auto border border-[#F27D26]/20 cursor-pointer"
                              >
                                <Send className="h-3 w-3" /> Push
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Modern Form Controller */}
                <div className="bg-[#15181F] p-5 rounded-xl border border-[#2A2D35] space-y-4">
                  <h3 className="font-bold text-white text-sm flex items-center gap-2 uppercase tracking-wider">
                    <Clock className="h-4 w-4 text-[#F27D26]" />
                    Set Period Alarm Schedule
                  </h3>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 mb-1 uppercase tracking-wider font-mono">Select Period</label>
                      <select 
                        value={selectedPeriodId}
                        onChange={(e) => setSelectedPeriodId(parseInt(e.target.value))}
                        className="w-full rounded-lg border border-[#2A2D35] p-2 text-sm bg-[#0F1115] text-white focus:outline-none focus:border-[#F27D26] font-mono"
                      >
                        {periods.map(p => (
                          <option key={p.id} value={p.id}>Period {p.id} ({p.periodName})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-400 mb-1 uppercase tracking-wider font-mono">Hour (24h)</label>
                      <input 
                        type="number"
                        min="0"
                        max="23"
                        value={inputHour}
                        onChange={(e) => setInputHour(e.target.value.padStart(2, '0').slice(-2))}
                        className="w-full rounded-lg border border-[#2A2D35] p-2 text-sm text-center bg-[#0F1115] text-[#00FF9C] focus:outline-none focus:border-[#F27D26] font-bold font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-400 mb-1 uppercase tracking-wider font-mono">Minute (00-59)</label>
                      <input 
                        type="number"
                        min="0"
                        max="59"
                        value={inputMinute}
                        onChange={(e) => setInputMinute(e.target.value.padStart(2, '0').slice(-2))}
                        className="w-full rounded-lg border border-[#2A2D35] p-2 text-sm text-center bg-[#0F1115] text-[#00FF9C] focus:outline-none focus:border-[#F27D26] font-bold font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-400 mb-1 uppercase tracking-wider font-mono">Duration (sec)</label>
                      <input 
                        type="number"
                        min="1"
                        max="120"
                        value={inputDuration}
                        onChange={(e) => setInputDuration(e.target.value)}
                        className="w-full rounded-lg border border-[#2A2D35] p-2 text-sm text-center bg-[#0F1115] text-[#00FF9C] focus:outline-none focus:border-[#F27D26] font-bold font-mono"
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => handleUpdateBellSim(selectedPeriodId, parseInt(inputHour), parseInt(inputMinute), parseInt(inputDuration))}
                    className="w-full bg-[#F27D26] hover:bg-[#ff8a3d] text-white font-bold py-2 px-4 rounded-lg text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 shadow-lg shadow-orange-950/20 cursor-pointer"
                  >
                    <Send className="h-4 w-4" /> Send Schedule Update to ESP32 Server
                  </button>
                </div>

                {/* Period Cards Grid Preview */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {periods.map(p => (
                    <div 
                      key={p.id} 
                      onClick={() => {
                        setSelectedPeriodId(p.id);
                        setInputHour(String(p.hour).padStart(2, '0'));
                        setInputMinute(String(p.minute).padStart(2, '0'));
                        setInputDuration(String(p.duration));
                      }}
                      className={`p-3 rounded-xl border transition-all cursor-pointer text-left relative overflow-hidden ${
                        selectedPeriodId === p.id 
                          ? 'border-[#F27D26] bg-[#F27D26]/5 shadow-lg shadow-orange-950/10' 
                          : 'border-[#2A2D35] hover:border-gray-600 bg-[#15181F]'
                      }`}
                    >
                      <span className="text-[10px] text-gray-500 font-bold block uppercase font-mono">Period {p.id}</span>
                      <span className="font-bold text-xs text-gray-200 block mt-0.5">{p.periodName}</span>
                      <span className="text-base font-bold font-mono text-[#00FF9C] mt-1.5 block">
                        {String(p.hour).padStart(2, '0')}:{String(p.minute).padStart(2, '0')}
                      </span>
                      <span className="text-[10px] text-gray-400 font-mono mt-0.5 block">
                        Ring: {p.duration}s
                      </span>
                      {selectedPeriodId === p.id && (
                        <span className="absolute top-2 right-2 bg-[#F27D26] text-white p-0.5 rounded-full">
                          <Check className="h-2.5 w-2.5" />
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Holiday list and manual triggers */}
        <div className="space-y-6">
          {/* Holidays and Manual Controls Card */}
          <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-2xl shadow-xl p-5 space-y-5">
            <h3 className="font-bold text-xs uppercase tracking-wider text-white pb-2 border-b border-[#2A2D35] flex items-center gap-2">
              <Plus className="h-4 w-4 text-[#00FF9C]" />
              Holiday list & Manual Triggers
            </h3>

            {/* Manual Bell Activation */}
            <div className="p-4 bg-[#030418] rounded-xl border border-[#F27D26]/15 space-y-3">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="font-bold text-xs text-orange-400 uppercase font-mono tracking-wider">manual bell on off</h4>
                  <p className="text-[10px] text-gray-400">तुरंत घंटी बजाएं या बंद करें</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-mono font-bold ${manualBellState ? 'text-[#00FF9C] animate-pulse' : 'text-gray-500'}`}>
                    {manualBellState ? 'RINGING' : 'MUTED'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleManualBellSim(true)}
                  className={`py-2 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    manualBellState 
                      ? 'bg-[#F27D26] text-white shadow-inner' 
                      : 'bg-[#15181F] hover:bg-[#F27D26]/10 text-[#F27D26] border border-[#F27D26]/20'
                  }`}
                >
                  🔔 Turn ON
                </button>
                <button
                  onClick={() => handleManualBellSim(false)}
                  className={`py-2 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    !manualBellState 
                      ? 'bg-[#2A2D35] text-gray-300 shadow-inner' 
                      : 'bg-[#15181F] hover:bg-gray-800 text-gray-300 border border-[#2A2D35]'
                  }`}
                >
                  🔕 Turn OFF
                </button>
              </div>
            </div>

            {/* Add Holiday Form */}
            <div className="space-y-3">
              <div>
                <h4 className="font-bold text-xs text-gray-400 uppercase tracking-wider font-mono bg-[#05082f]">add Holiday list bell off</h4>
                <p className="text-[10px] text-gray-500">छुट्टी वाले दिन अलार्म अपने-आप बंद रहेगा</p>
              </div>

              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold font-mono text-gray-500 mb-0.5 uppercase tracking-wider">Date (DD-MM-YYYY)</label>
                    <input
                      type="text"
                      placeholder="e.g. 15-08-2026"
                      value={holidayDate}
                      onChange={(e) => setHolidayDate(e.target.value)}
                      className="w-full rounded-lg border border-[#2A2D35] px-2 py-1.5 text-xs font-mono bg-[#0F1115] text-white focus:outline-none focus:border-[#00FF9C]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold font-mono text-gray-500 mb-0.5 uppercase tracking-wider">Label</label>
                    <input
                      type="text"
                      placeholder="e.g. Independence"
                      value={holidayLabel}
                      onChange={(e) => setHolidayLabel(e.target.value)}
                      className="w-full rounded-lg border border-[#2A2D35] px-2 py-1.5 text-xs bg-[#0F1115] text-white focus:outline-none focus:border-[#00FF9C]"
                    />
                  </div>
                </div>

                <button
                  onClick={() => handleAddHolidaySim(holidayDate, holidayLabel)}
                  className="w-full bg-[#00FF9C] hover:bg-[#12ffab] text-[#0F1115] text-xs font-bold py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Plus className="h-3.5 w-3.5 text-[#0F1115]" /> Add Holiday
                </button>
              </div>
            </div>

            {/* Holiday List Grid */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider block font-mono">Scheduled Holidays</span>
              {holidays.length === 0 ? (
                <div className="text-xs text-gray-500 italic text-center py-4 bg-[#15181F] rounded-xl border border-dashed border-[#2A2D35]">
                  No holidays added yet.
                </div>
              ) : (
                <div className="max-h-[160px] overflow-y-auto space-y-1.5 pr-1 font-mono text-xs">
                  {holidays.map(h => (
                    <div key={h.id} className="flex items-center justify-between p-2 bg-[#15181F] border border-[#2A2D35] rounded-lg">
                      <div>
                        <span className="font-bold text-[#00FF9C] mr-2">{h.date}</span>
                        <span className="text-gray-400 text-[10px] font-sans">({h.label})</span>
                      </div>
                      <button
                        onClick={() => deleteHoliday(h.id)}
                        className="text-gray-500 hover:text-[#F27D26] p-1 rounded transition-colors cursor-pointer"
                        title="Delete Holiday"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Active Command Inspector Panel */}
          <div className="bg-[#090a3b] border border-[#2A2D35] rounded-2xl p-4 text-[#E0E0E0] shadow-xl font-mono text-xs space-y-3">
            <h3 className="font-bold text-[#F27D26] flex items-center gap-1.5 text-[11px] uppercase tracking-wider pb-1.5 border-b border-[#2A2D35]">
              <Server className="h-3.5 w-3.5 text-[#F27D26]" />
              Latest Network Dispatch Inspector
            </h3>
            
            <div className="space-y-2.5 text-left">
              <div>
                <span className="text-gray-500 font-bold block mb-1 text-[10px] uppercase font-mono tracking-wider">App Http Get URL</span>
                <div className="bg-black/30 p-2 rounded-lg border border-[#2A2D35] text-gray-300 whitespace-pre-wrap break-all select-all font-semibold font-mono">
                  {lastApiUrl || 'None. Trigger a command above!'}
                </div>
              </div>

              <div>
                <span className="text-[#00FF9C] font-bold block mb-1 text-[10px] uppercase font-mono tracking-wider">ESP32 → STM32 Serial Message</span>
                <div className="bg-black/30 p-2 rounded-lg border border-[#2A2D35] text-[#00FF9C] font-bold whitespace-pre-wrap break-all font-mono">
                  {lastSerialCmd || 'None. Trigger a command above!'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
