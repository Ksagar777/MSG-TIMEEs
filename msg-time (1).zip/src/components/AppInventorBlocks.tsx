import React, { useState } from 'react';
import { HelpCircle, ChevronRight, Download, BookOpen, AlertCircle, Laptop, Wifi, ArrowRight, Play, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function AppInventorBlocks() {
  const [activeMethod, setActiveMethod] = useState<'mdns' | 'scanner'>('mdns');
  const [language, setLanguage] = useState<'hinglish' | 'english'>('hinglish');

  return (
    <div className="space-y-6" id="app-inventor-blocks-section">
      {/* Control Bar */}
      <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div>
          <h2 className="font-bold text-white text-base flex items-center gap-2 uppercase tracking-wider">
            <BookOpen className="h-5 w-5 text-[#F27D26]" />
            MIT App Inventor: Automatic IP & Block Guide
          </h2>
          <p className="text-xs text-gray-400">
            {language === 'hinglish' 
              ? 'बिना IP डाले, मोबाइल ऐप को ESP32 से ऑटोमैटिक कनेक्ट करने का ब्लॉक लॉजिक'
              : 'Block logic for connecting mobile app to ESP32 automatically without entering IP address'
            }
          </p>
        </div>

        <div className="flex gap-2 self-start sm:self-center">
          {/* Language Selector */}
          <div className="bg-[#0F1115] p-1 rounded-lg flex text-xs font-bold border border-[#2A2D35]">
            <button
              onClick={() => setLanguage('hinglish')}
              className={`px-3 py-1.5 rounded-md transition-all cursor-pointer ${language === 'hinglish' ? 'bg-[#F27D26] text-white shadow-md' : 'text-gray-400 hover:text-white'}`}
            >
              Hinglish (हिंदी)
            </button>
            <button
              onClick={() => setLanguage('english')}
              className={`px-3 py-1.5 rounded-md transition-all cursor-pointer ${language === 'english' ? 'bg-[#F27D26] text-white shadow-md' : 'text-gray-400 hover:text-white'}`}
            >
              English
            </button>
          </div>
        </div>
      </div>

      {/* Method Selection Tabs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Method 1: mDNS */}
        <div 
          onClick={() => setActiveMethod('mdns')}
          className={`p-5 rounded-2xl border-2 transition-all cursor-pointer text-left relative overflow-hidden ${
            activeMethod === 'mdns' 
              ? 'border-[#F27D26] bg-[#F27D26]/5 shadow-lg shadow-orange-950/10' 
              : 'border-[#2A2D35] bg-[#1A1D24] hover:border-gray-600'
          }`}
        >
          <div className="flex items-start gap-3">
            <div className={`p-2 rounded-xl border ${activeMethod === 'mdns' ? 'bg-[#F27D26]/10 border-[#F27D26]/30 text-[#F27D26]' : 'bg-[#0F1115] border-[#2A2D35] text-gray-500'}`}>
              <Wifi className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-[#F27D26] uppercase tracking-wider bg-[#F27D26]/10 px-2 py-0.5 rounded-full font-mono">Method 1 (Recommended)</span>
              <h3 className="font-bold text-white text-sm mt-2">mDNS Hostname Address (.local)</h3>
              <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                {language === 'hinglish'
                  ? 'सबसे आसान तरीका! बिना किसी स्कैनिंग ब्लॉक के, सीधे "http://schoolbell.local" डोमेन से कनेक्ट करें।'
                  : 'Easiest way! Target the hostname "http://schoolbell.local" directly, no IP lookup logic needed.'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Method 2: Scanner */}
        <div 
          onClick={() => setActiveMethod('scanner')}
          className={`p-5 rounded-2xl border-2 transition-all cursor-pointer text-left relative overflow-hidden ${
            activeMethod === 'scanner' 
              ? 'border-[#F27D26] bg-[#F27D26]/5 shadow-lg shadow-orange-950/10' 
              : 'border-[#2A2D35] bg-[#1A1D24] hover:border-gray-600'
          }`}
        >
          <div className="flex items-start gap-3">
            <div className={`p-2 rounded-xl border ${activeMethod === 'scanner' ? 'bg-[#F27D26]/10 border-[#F27D26]/30 text-[#F27D26]' : 'bg-[#0F1115] border-[#2A2D35] text-gray-500'}`}>
              <Play className="h-5 w-5 animate-pulse text-[#F27D26]" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-[#00FF9C] uppercase tracking-wider bg-[#00FF9C]/10 px-2 py-0.5 rounded-full font-mono">Method 2 (Advanced)</span>
              <h3 className="font-bold text-white text-sm mt-2">Local Network IP Subnet Scanner</h3>
              <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                {language === 'hinglish'
                  ? 'अगर राउटर पुराना है तो ऐप खुद बैकग्राउंड में 192.168.1.1 से 192.168.1.254 तक स्कैन करके ESP32 खोज लेगा!'
                  : 'If the router is old, the app itself scans from 192.168.1.1 to 192.168.1.254 in background to find ESP32!'
                }
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Blocks Visualizer Panel */}
      <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-3xl shadow-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
        
        {/* Left Column: Visual Blocks Canvas */}
        <div className="lg:col-span-8 bg-[#0F1115] p-6 flex flex-col min-h-[500px] border-b lg:border-b-0 lg:border-r border-[#2A2D35]">
          <div className="flex items-center justify-between pb-4 border-b border-[#2A2D35] mb-6">
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
              🧩 MIT App Inventor 2: Block Editor Workspace
            </span>
            <div className="flex items-center gap-1.5 bg-black/40 px-2 py-1 rounded text-[10px] font-mono text-[#00FF9C] border border-[#2A2D35]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#00FF9C] animate-pulse" />
              Interactive Layout
            </div>
          </div>

          {/* Interactive Block Puzzle Render */}
          <div className="flex-grow flex flex-col justify-center items-center overflow-auto py-4">
            {activeMethod === 'mdns' ? (
              <div className="space-y-6 w-full max-w-xl">
                {/* Block 1: Initialize Global URL */}
                <div className="flex flex-col items-start font-sans">
                  {/* Outer Block Frame */}
                  <div className="bg-orange-500 text-white text-xs font-bold px-4 py-2.5 rounded-t-xl rounded-r-xl relative flex items-center gap-2 shadow-md border-l-4 border-orange-700 min-w-[280px]">
                    <span className="bg-orange-700 text-white rounded px-1.5 py-0.5 text-[9px] mr-1">Variable</span>
                    initialize global <span className="text-yellow-200">ESP32_URL</span> to
                    <div className="absolute left-1/3 -bottom-1.5 w-4 h-3 bg-orange-500 rounded-b-full z-10"></div>
                  </div>
                  {/* Inside Attached Block */}
                  <div className="ml-8 bg-pink-600 text-white text-xs font-mono px-4 py-2 rounded-r-xl rounded-b-xl border-l-4 border-pink-800 shadow-md flex items-center gap-1.5">
                    "
                    <span className="text-pink-100 font-bold font-sans">http://schoolbell.local</span>
                    "
                  </div>
                </div>

                {/* Block 2: When Button_Update Click */}
                <div className="flex flex-col items-start">
                  <div className="bg-yellow-600 text-white text-xs font-bold px-4 py-3 rounded-t-2xl rounded-r-2xl relative flex items-center gap-1 shadow-md border-l-4 border-yellow-800 min-w-[320px]">
                    <span className="bg-yellow-800 text-white rounded px-1 text-[9px]">Event</span>
                    when <span className="text-yellow-100">Button_Update.Click</span> do
                  </div>
                  
                  {/* Inside Slot */}
                  <div className="ml-6 border-l-4 border-yellow-700 pl-4 py-3 space-y-3 bg-[#1A1D24]/40 rounded-b-xl pr-4 w-full">
                    
                    {/* set Web1.Url to ... */}
                    <div className="flex flex-col items-start">
                      <div className="bg-emerald-600 text-white text-xs font-bold px-3 py-2 rounded-t-lg rounded-r-lg relative flex items-center gap-1.5 border-l-4 border-emerald-800">
                        set <span className="text-emerald-100">Web1.Url</span> to
                      </div>
                      
                      {/* join blocks */}
                      <div className="ml-4 bg-teal-600 text-white text-xs font-bold px-3 py-1.5 rounded-r-lg border-l-4 border-teal-800 flex flex-wrap items-center gap-1">
                        <span className="bg-teal-800 text-[9px] px-1 rounded">Text</span>
                        join
                        <div className="flex flex-col gap-1.5 ml-2 mt-1 bg-teal-900/40 p-2 rounded">
                          {/* Part 1 */}
                          <div className="bg-orange-500 text-white px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1">
                            get <span className="text-yellow-200">global ESP32_URL</span>
                          </div>
                          {/* Part 2 */}
                          <div className="bg-pink-600 text-white px-2 py-0.5 rounded text-[10px] font-mono">
                            "/updateBell?period="
                          </div>
                          {/* Part 3 */}
                          <div className="bg-emerald-600 text-white px-2 py-0.5 rounded text-[10px]">
                            get <span className="font-semibold text-emerald-100">TextBox_Period.Text</span>
                          </div>
                          {/* Part 4 */}
                          <div className="bg-pink-600 text-white px-2 py-0.5 rounded text-[10px] font-mono">
                            "&hour="
                          </div>
                          {/* Part 5 */}
                          <div className="bg-emerald-600 text-white px-2 py-0.5 rounded text-[10px]">
                            get <span className="font-semibold text-emerald-100">TextBox_Hour.Text</span>
                          </div>
                          {/* Part 6 */}
                          <div className="bg-pink-600 text-white px-2 py-0.5 rounded text-[10px] font-mono">
                            "&minute="
                          </div>
                          {/* Part 7 */}
                          <div className="bg-emerald-600 text-white px-2 py-0.5 rounded text-[10px]">
                            get <span className="font-semibold text-emerald-100">TextBox_Minute.Text</span>
                          </div>
                          {/* Part 8 */}
                          <div className="bg-pink-600 text-white px-2 py-0.5 rounded text-[10px] font-mono">
                            "&duration="
                          </div>
                          {/* Part 9 */}
                          <div className="bg-emerald-600 text-white px-2 py-0.5 rounded text-[10px]">
                            get <span className="font-semibold text-emerald-100">TextBox_Duration.Text</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* call Web1.Get */}
                    <div className="bg-indigo-600 text-white text-xs font-bold px-4 py-2 rounded-lg border-l-4 border-indigo-800 shadow-sm inline-block">
                      call <span className="text-indigo-100">Web1.Get</span>
                    </div>

                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-6 w-full max-w-xl text-left scale-95 origin-center">
                {/* Variables used */}
                <div className="grid grid-cols-2 gap-2 pb-2 font-mono">
                  <div className="bg-[#1A1D24] p-2.5 rounded-xl border border-[#2A2D35]">
                    <span className="text-[10px] font-mono text-[#F27D26] font-bold block uppercase tracking-wider">Var: global Scanner_Counter</span>
                    <span className="text-white text-xs font-bold">1</span>
                  </div>
                  <div className="bg-[#1A1D24] p-2.5 rounded-xl border border-[#2A2D35]">
                    <span className="text-[10px] font-mono text-[#00FF9C] font-bold block uppercase tracking-wider">Var: global ESP32_IP</span>
                    <span className="text-white text-xs font-bold">"Not Discovered"</span>
                  </div>
                </div>

                {/* Clock.Timer Event Block */}
                <div className="flex flex-col items-start font-sans">
                  <div className="bg-yellow-600 text-white text-xs font-bold px-4 py-3 rounded-t-xl rounded-r-xl relative flex items-center gap-1.5 shadow-md border-l-4 border-yellow-800 min-w-[340px]">
                    <span className="bg-yellow-800 text-white rounded px-1.5 py-0.5 text-[9px]">Event</span>
                    when <span className="text-yellow-100">Clock_Scanner.Timer</span> do
                  </div>

                  <div className="ml-6 border-l-4 border-yellow-700 pl-4 py-3 space-y-3 bg-[#1A1D24]/40 rounded-b-xl pr-4 w-full">
                    {/* IF block */}
                    <div className="bg-sky-600 text-white text-xs font-bold px-3 py-2.5 rounded-t-lg rounded-r-lg border-l-4 border-sky-800 flex items-center gap-2">
                      <span className="bg-sky-800 text-[9px] px-1 rounded">Control</span>
                      if <span className="text-sky-100 font-bold">get global Scanner_Counter &gt; 254</span> then
                    </div>

                    {/* Inside Then: Stop timer and error */}
                    <div className="ml-4 border-l-2 border-sky-700 pl-3 py-1 space-y-2">
                      <div className="bg-emerald-600 text-white text-xs font-bold px-3 py-1.5 rounded border-l-4 border-emerald-800">
                        set <span className="text-emerald-100">Clock_Scanner.TimerEnabled</span> to <span className="text-amber-200">false</span>
                      </div>
                      <div className="bg-emerald-600 text-white text-xs font-bold px-3 py-1.5 rounded border-l-4 border-emerald-800">
                        set <span className="text-emerald-100">Label_Status.Text</span> to <span className="text-pink-200">"Connection Failed"</span>
                      </div>
                    </div>

                    {/* ELSE block */}
                    <div className="bg-sky-600 text-white text-xs font-bold px-3 py-1.5 rounded border-l-4 border-sky-800">
                      else
                    </div>

                    {/* Inside Else: Set Web1.Url and Get */}
                    <div className="ml-4 border-l-2 border-sky-700 pl-3 py-1 space-y-3">
                      <div className="bg-emerald-600 text-white text-xs font-bold px-3 py-2 rounded border-l-4 border-emerald-800 flex flex-col gap-1.5">
                        <span>set <span className="text-emerald-100">Web_Scanner.Url</span> to</span>
                        <div className="ml-2 bg-teal-600 text-white px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1">
                          join ( "http://192.168.1." , <span className="text-orange-300">get global Scanner_Counter</span> , "/api/health" )
                        </div>
                      </div>

                      <div className="bg-indigo-600 text-white text-xs font-bold px-3 py-1.5 rounded border-l-4 border-indigo-800 inline-block">
                        call <span className="text-indigo-100">Web_Scanner.Get</span>
                      </div>

                      <div className="bg-emerald-600 text-white text-xs font-bold px-3 py-2 rounded border-l-4 border-emerald-800">
                        set <span className="text-emerald-100">global Scanner_Counter</span> to <span className="text-amber-200">get global Scanner_Counter + 1</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Web_Scanner.GotText Event Block */}
                <div className="flex flex-col items-start font-sans border border-[#2A2D35] p-2 rounded-2xl bg-black/20">
                  <div className="bg-yellow-600 text-white text-xs font-bold px-4 py-3 rounded-t-xl rounded-r-xl relative flex items-center gap-1.5 shadow-md border-l-4 border-yellow-800 min-w-[340px]">
                    <span className="bg-yellow-800 text-white rounded px-1.5 py-0.5 text-[9px]">Event</span>
                    when <span className="text-yellow-100">Web_Scanner.GotText</span> (url, responseCode, responseContent) do
                  </div>

                  <div className="ml-6 border-l-4 border-yellow-700 pl-4 py-3 space-y-3 bg-[#1A1D24]/40 rounded-b-xl pr-4 w-full text-xs">
                    <div className="bg-sky-600 text-white text-xs font-bold px-3 py-1.5 rounded border-l-4 border-sky-800">
                      if <span className="text-sky-100 font-bold">responseCode = 200</span> and <span className="text-sky-100 font-bold">responseContent = "OK"</span> then
                    </div>

                    <div className="ml-4 border-l-2 border-sky-700 pl-3 py-1 space-y-2">
                      <div className="bg-emerald-600 text-white px-3 py-1.5 rounded border-l-4 border-emerald-800">
                        set <span className="text-emerald-100">Clock_Scanner.TimerEnabled</span> to <span className="text-amber-200">false</span>
                      </div>
                      <div className="bg-emerald-600 text-white px-3 py-1.5 rounded border-l-4 border-emerald-800">
                        set <span className="text-emerald-100">global ESP32_IP</span> to <span className="text-indigo-200">extract IP from url</span>
                      </div>
                      <div className="bg-emerald-600 text-white px-3 py-1.5 rounded border-l-4 border-emerald-800">
                        set <span className="text-emerald-100">Label_Status.Text</span> to <span className="text-[#00FF9C] font-semibold">"ESP32 Connected Automatically!"</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Descriptions & Step-by-Step */}
        <div className="lg:col-span-4 p-6 space-y-6">
          <div className="bg-[#F27D26]/5 border border-[#F27D26]/20 rounded-2xl p-4">
            <h4 className="font-bold text-[#F27D26] text-xs flex items-center gap-1.5 uppercase tracking-wider font-mono">
              <AlertCircle className="h-4 w-4 text-[#F27D26]" />
              {language === 'hinglish' ? 'ऑटोमैटिक IP का सिद्धांत' : 'How Auto IP Discovery Works'}
            </h4>
            <p className="text-xs text-gray-300 mt-2 leading-relaxed">
              {language === 'hinglish' ? (
                <>
                  ESP32 जब चालू होता है तो राउटर उसे कोई भी IP (जैसे 192.168.1.12 या 192.168.1.45) अलॉट कर सकता है। बार-बार IP टाइप करने की झंझट खत्म करने के लिए हमारे पास दो तरीके हैं:
                </>
              ) : (
                <>
                  ESP32 gets dynamically assigned an IP from the router. To eliminate the friction of typing the IP every time, we utilize these techniques:
                </>
              )}
            </p>
          </div>

          {activeMethod === 'mdns' ? (
            <div className="space-y-4">
              <h3 className="font-bold text-xs uppercase tracking-wider text-[#F27D26] font-mono">
                {language === 'hinglish' ? 'विधि 1: mDNS निर्देश' : 'Method 1: mDNS Guide'}
              </h3>
              
              <ul className="space-y-3.5 text-xs text-gray-300 leading-relaxed">
                <li className="flex gap-2">
                  <span className="font-bold text-[#F27D26] bg-[#F27D26]/10 h-5 w-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-mono border border-[#F27D26]/20">1</span>
                  <span>
                    <strong>{language === 'hinglish' ? 'Hostname सेट करें:' : 'Assign Hostname:'}</strong><br />
                    {language === 'hinglish' 
                      ? 'हमने ESP32 कोड में MDNS.begin("schoolbell") जोड़ा है।'
                      : 'We start MDNS.begin("schoolbell") in ESP32 firmware.'
                    }
                  </span>
                </li>
                <li className="flex gap-2">
                  <span className="font-bold text-[#F27D26] bg-[#F27D26]/10 h-5 w-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-mono border border-[#F27D26]/20">2</span>
                  <span>
                    <strong>{language === 'hinglish' ? 'नॉर्मल ब्लॉक बनाएं:' : 'Simplified Blocks:'}</strong><br />
                    {language === 'hinglish' 
                      ? 'App Inventor में सिर्फ एक Variable बनाएं और उसमें "http://schoolbell.local" लिख दें।'
                      : 'In App Inventor, declare a variable and store "http://schoolbell.local" as value.'
                    }
                  </span>
                </li>
                <li className="flex gap-2">
                  <span className="font-bold text-[#F27D26] bg-[#F27D26]/10 h-5 w-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-mono border border-[#F27D26]/20">3</span>
                  <span>
                    <strong>{language === 'hinglish' ? 'फायदा:' : 'Advantage:'}</strong><br />
                    {language === 'hinglish' 
                      ? 'राउटर चाहे जो भी IP बदले, आपका फोन हमेशा "schoolbell.local" पर ही रिक्वेस्ट भेजेगा और राउटर उसे खुद ESP32 पर पहुंचा देगा!'
                      : 'Regardless of the dynamic IP, the phone will resolve "schoolbell.local" automatically using native router multicast.'
                    }
                  </span>
                </li>
              </ul>
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="font-bold text-xs uppercase tracking-wider text-[#00FF9C] font-mono">
                {language === 'hinglish' ? 'विधि 2: सबनेट स्कैनर गाइड' : 'Method 2: Subnet Scanner Guide'}
              </h3>
              
              <ul className="space-y-3.5 text-xs text-gray-300 leading-relaxed">
                <li className="flex gap-2">
                  <span className="font-bold text-[#00FF9C] bg-[#00FF9C]/10 h-5 w-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-mono border border-[#00FF9C]/20">1</span>
                  <span>
                    <strong>{language === 'hinglish' ? 'Clock कंपोनेंट लगाएं:' : 'Add Clock Component:'}</strong><br />
                    {language === 'hinglish' 
                      ? 'App Inventor में एक Clock लगाएं जिसका TimerInterval = 100ms हो।'
                      : 'Add a Clock component in App Inventor with TimerInterval = 100ms.'
                    }
                  </span>
                </li>
                <li className="flex gap-2">
                  <span className="font-bold text-[#00FF9C] bg-[#00FF9C]/10 h-5 w-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-mono border border-[#00FF9C]/20">2</span>
                  <span>
                    <strong>{language === 'hinglish' ? '1 से 254 तक चेक:' : 'Loop from 1 to 254:'}</strong><br />
                    {language === 'hinglish' 
                      ? 'जैसे ही ऐप चालू हो, क्लॉक हर 100ms में IP के आखिरी नंबर को बढ़ाएगा (192.168.1.1, फिर 1.2, फिर 1.3) और /api/health रिक्वेस्ट भेजेगा।'
                      : 'On start, the clock increments the IP octet every 100ms (192.168.1.1, 1.2, 1.3...) and makes a light request to /api/health.'
                    }
                  </span>
                </li>
                <li className="flex gap-2">
                  <span className="font-bold text-[#00FF9C] bg-[#00FF9C]/10 h-5 w-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-mono border border-[#00FF9C]/20">3</span>
                  <span>
                    <strong>{language === 'hinglish' ? 'सक्सेस पर रोकें:' : 'Stop on Success:'}</strong><br />
                    {language === 'hinglish' 
                      ? 'जिस IP से "OK" रिस्पॉन्स आएगा, वही हमारे ESP32 का IP होगा। ऐप उस IP को सेव करके स्कैनर क्लॉक को स्टॉप कर देगा!'
                      : 'When any IP returns "OK", it is locked as our ESP32 IP, and scanning clock is disabled.'
                    }
                  </span>
                </li>
              </ul>
            </div>
          )}

          <div className="bg-[#15181F] border border-[#2A2D35] rounded-2xl p-4 text-xs">
            <h4 className="font-bold text-white flex items-center gap-1.5 uppercase font-mono text-[11px] tracking-wider mb-2">
              <Laptop className="h-4 w-4 text-gray-400" />
              {language === 'hinglish' ? 'MIT ऐप में क्या-क्या जोड़ना है:' : 'App Inventor Designer Setup:'}
            </h4>
            <div className="space-y-2 text-gray-300 font-mono text-[10px]">
              <div className="flex justify-between border-b border-[#2A2D35] pb-1.5">
                <span>1. Web component</span>
                <span className="text-[#F27D26] font-bold">Web1</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2D35] pb-1.5">
                <span>2. Subnet Scanner Web</span>
                <span className="text-[#F27D26] font-bold">Web_Scanner</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2D35] pb-1.5">
                <span>3. Timer Clock</span>
                <span className="text-[#F27D26] font-bold">Clock_Scanner</span>
              </div>
              <div className="flex justify-between">
                <span>4. Local status label</span>
                <span className="text-[#F27D26] font-bold">Label_Status</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
