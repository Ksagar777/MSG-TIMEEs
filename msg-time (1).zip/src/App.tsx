import React, { useState, useEffect } from 'react';
import { BellPeriod, SystemLog, Holiday } from './types';
import BellSimulator from './components/BellSimulator';
import AppInventorBlocks from './components/AppInventorBlocks';
import FirmwareGuide from './components/FirmwareGuide';
import PhonePreview from './components/PhonePreview';
import ApkCompilerGuide from './components/ApkCompilerGuide';
import { 
  Bell, BookOpen, Terminal, Wifi, Smartphone, Cpu, Settings, Activity, Trash2, ShieldCheck, RefreshCw, Volume2, Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const INITIAL_PERIODS: BellPeriod[] = [
  { id: 1, periodName: "Period 1", hour: 8, minute: 30, duration: 5 },
  { id: 2, periodName: "Period 2", hour: 9, minute: 15, duration: 5 },
  { id: 3, periodName: "Period 3", hour: 10, minute: 0, duration: 5 },
  { id: 4, periodName: "Period 4", hour: 10, minute: 45, duration: 5 },
  { id: 5, periodName: "Break Time", hour: 11, minute: 30, duration: 10 },
  { id: 6, periodName: "Period 5", hour: 12, minute: 0, duration: 5 },
  { id: 7, periodName: "Period 6", hour: 12, minute: 45, duration: 5 },
  { id: 8, periodName: "Period 7", hour: 13, minute: 30, duration: 5 },
  { id: 9, periodName: "Period 8", hour: 14, minute: 15, duration: 5 },
  { id: 10, periodName: "Period 9", hour: 15, minute: 0, duration: 5 },
  { id: 11, periodName: "Period 10", hour: 15, minute: 45, duration: 5 },
  { id: 12, periodName: "Overtime Bell", hour: 16, minute: 30, duration: 5 }
];

const INITIAL_HOLIDAYS: Holiday[] = [
  { id: '1', date: "15-08-2026", label: "Independence Day" },
  { id: '2', date: "02-10-2026", label: "Gandhi Jayanti" }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'blocks' | 'firmware' | 'preview' | 'apk'>('simulator');
  const [periods, setPeriods] = useState<BellPeriod[]>(INITIAL_PERIODS);
  const [holidays, setHolidays] = useState<Holiday[]>(INITIAL_HOLIDAYS);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  
  // IP Config States
  const [espIp, setEspIp] = useState<string>('schoolbell.local');
  const [isMdnsEnabled, setIsMdnsEnabled] = useState<boolean>(true);

  // Helper to add serial debugger logs
  const addLog = (type: 'ESP32' | 'STM32' | 'APP' | 'SYSTEM', message: string, isCommand = false) => {
    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newLog: SystemLog = {
      id: Math.random().toString(),
      timestamp,
      type,
      message,
      isCommand
    };
    setLogs(prev => [newLog, ...prev].slice(0, 150)); // Cap logs at 150
  };

  // Clear log history
  const clearLogs = () => {
    setLogs([]);
    addLog('SYSTEM', 'Debugger Serial Logs cleared.');
  };

  // Seed initial system startup logs on mount
  useEffect(() => {
    addLog('SYSTEM', 'MSGTIME Simulator initialized.');
    addLog('ESP32', 'Initializing WiFi Controller...');
    addLog('ESP32', 'AP Search mode active (MultiWiFi: "MSG", "B O_OFFICE").');
    addLog('ESP32', 'WiFi status: Connected. IP Address: 192.168.1.50');
    addLog('ESP32', 'mDNS Responder Registered: http://schoolbell.local');
    addLog('ESP32', 'HTTP Web Server started successfully on port 80.');
    addLog('STM32', 'Serial2 hardware link established at 9600 bps.');
    addLog('STM32', 'Internal Real-Time Clock (RTC) chip initialized.');
  }, []);

  return (
    <div className="min-h-screen bg-[#0F1115] text-[#E0E0E0] font-sans flex flex-col">
      
      {/* Dynamic Header */}
      <header className="bg-[#15181F] text-white shrink-0 border-b border-[#2A2D35]">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Logo branding */}
            <div className="flex items-center gap-3">
              <div className="p-2 bg-[#F27D26] rounded-xl shadow-lg shadow-orange-950/20 text-white">
                <Bell className="h-6 w-6 animate-pulse text-white" />
              </div>
              <div className="text-left">
                <h1 className="text-lg font-bold tracking-tight sm:text-xl font-sans text-white flex items-center gap-2">
                  MSGTIME
                  <span className="text-[10px] font-mono bg-[#00FF9C]/10 text-[#00FF9C] px-2 py-0.5 rounded-full border border-[#00FF9C]/20 font-semibold uppercase tracking-wider">
                    v2.4
                  </span>
                </h1>
                <p className="text-xs text-gray-400 font-mono tracking-wider uppercase mt-0.5" style={{ backgroundColor: '#120202', color: '#070707' }}>
                  ESP32 & STM32 Synchronized System
                </p>
              </div>
            </div>

            {/* Quick settings toolbar */}
            <div className="flex items-center gap-3 bg-[#1A1D24] p-2 rounded-xl border border-[#2A2D35]">
              <div className="text-left font-mono text-[10px]">
                <span className="text-gray-500 block uppercase font-bold tracking-wider">Base App Address</span>
                <input 
                  type="text" 
                  value={espIp}
                  onChange={(e) => {
                    const val = e.target.value;
                    setEspIp(val);
                    setIsMdnsEnabled(val.includes('.local'));
                  }}
                  className="bg-transparent text-[#00FF9C] font-bold border-none outline-none focus:ring-0 p-0 w-32 font-mono"
                  placeholder="e.g. schoolbell.local"
                />
              </div>
              <div className="h-6 w-px bg-[#2A2D35]" />
              <div className="flex items-center gap-1.5 px-2">
                <span className={`h-2 w-2 rounded-full ${isMdnsEnabled ? 'bg-[#00FF9C] animate-pulse' : 'bg-amber-500'}`} />
                <span className="text-[9px] font-bold font-mono uppercase tracking-wider text-gray-400">
                  {isMdnsEnabled ? 'mDNS Domain' : 'IP Address'}
                </span>
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 py-6 sm:px-6 lg:px-8 flex flex-col lg:flex-row gap-6 bg-[#180733]">
        
        {/* Left Side: Main tab panel */}
        <div className="flex-grow space-y-6 lg:w-3/4">
          
          {/* Navigation Bar */}
          <div className="flex overflow-x-auto bg-[#1A1D24] p-1 rounded-2xl border border-[#2A2D35] shadow-sm scrollbar-hide">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                activeTab === 'simulator' 
                  ? 'bg-[#F27D26] text-white shadow-lg shadow-orange-950/30' 
                  : 'text-gray-400 hover:bg-[#252932] hover:text-white'
              }`}
            >
              <Cpu className="h-4 w-4" />
              1. Hardware Simulator
            </button>
            <button
              onClick={() => setActiveTab('blocks')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                activeTab === 'blocks' 
                  ? 'bg-[#F27D26] text-white shadow-lg shadow-orange-950/30' 
                  : 'text-gray-400 hover:bg-[#252932] hover:text-white'
              }`}
            >
              <BookOpen className="h-4 w-4" />
              2. MIT Inventor Blocks
            </button>
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                activeTab === 'preview' 
                  ? 'bg-[#F27D26] text-white shadow-lg shadow-orange-950/30' 
                  : 'text-gray-400 hover:bg-[#252932] hover:text-white'
              }`}
            >
              <Smartphone className="h-4 w-4" />
              3. Android Phone Mockup
            </button>
            <button
              onClick={() => setActiveTab('firmware')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                activeTab === 'firmware' 
                  ? 'bg-[#F27D26] text-white shadow-lg shadow-orange-950/30' 
                  : 'text-gray-400 hover:bg-[#252932] hover:text-white'
              }`}
            >
              <Terminal className="h-4 w-4" />
              4. C++ Firmware Codes
            </button>
            <button
              onClick={() => setActiveTab('apk')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                activeTab === 'apk' 
                  ? 'bg-[#F27D26] text-white shadow-lg shadow-orange-950/30' 
                  : 'text-gray-400 hover:bg-[#252932] hover:text-white'
              }`}
            >
              <Sparkles className="h-4 w-4" />
              5. Build Android APK
            </button>
          </div>

          {/* Render Active Tab Pane */}
          <div className="min-h-[400px]">
            {activeTab === 'simulator' && (
              <BellSimulator
                periods={periods}
                setPeriods={setPeriods}
                holidays={holidays}
                setHolidays={setHolidays}
                logs={logs}
                addLog={addLog}
                clearLogs={clearLogs}
                espIp={espIp}
                isMdnsEnabled={isMdnsEnabled}
              />
            )}
            {activeTab === 'blocks' && (
              <AppInventorBlocks />
            )}
            {activeTab === 'preview' && (
              <PhonePreview
                periods={periods}
                setPeriods={setPeriods}
                holidays={holidays}
                setHolidays={setHolidays}
                addLog={addLog}
                espIp={espIp}
              />
            )}
            {activeTab === 'firmware' && (
              <FirmwareGuide />
            )}
            {activeTab === 'apk' && (
              <ApkCompilerGuide />
            )}
          </div>
        </div>

        {/* Right Side: Serial Debugger Output Terminal Panel */}
        <div className="lg:w-1/4 shrink-0 flex flex-col min-h-[450px]">
          <div className="bg-[#1A1D24] border border-[#2A2D35] rounded-2xl flex flex-col flex-grow text-[#E0E0E0] font-mono text-xs overflow-hidden shadow-xl">
            {/* Terminal Header */}
            <div className="bg-[#15181F] px-4 py-3 border-b border-[#2A2D35] flex items-center justify-between">
              <div className="flex items-center gap-2 text-gray-300 font-sans font-bold text-[11px] uppercase tracking-wider">
                <Terminal className="h-4 w-4 text-[#00FF9C]" />
                STM32 Serial Console
              </div>
              <button
                onClick={clearLogs}
                title="Clear Logs"
                className="text-gray-500 hover:text-white p-1 hover:bg-[#252932] rounded transition-colors"
              >
                <Trash2 className="h-3.5 w-3.5 text-[#F27D26]" />
              </button>
            </div>

            {/* Terminal Screen lines */}
            <div className="flex-grow overflow-y-auto p-4 space-y-2 text-left max-h-[500px] lg:max-h-none bg-black/40">
              {logs.length === 0 ? (
                <div className="text-gray-600 text-center py-10 font-sans italic text-xs">
                  Console idle. Trigger an action or wait for the NTP clock tick.
                </div>
              ) : (
                <div className="space-y-1.5 leading-relaxed text-[11px]">
                  {logs.map((log) => {
                    let typeColor = 'text-gray-500';
                    let label = 'SYS';
                    
                    if (log.type === 'ESP32') {
                      typeColor = 'text-[#F27D26] font-semibold';
                      label = 'ESP32';
                    } else if (log.type === 'STM32') {
                      typeColor = 'text-[#00FF9C] font-semibold';
                      label = 'STM32';
                    } else if (log.type === 'APP') {
                      typeColor = 'text-sky-400 font-semibold';
                      label = 'PHONE';
                    } else if (log.type === 'SYSTEM') {
                      typeColor = 'text-amber-400 font-semibold';
                      label = 'CLOCK';
                    }

                    return (
                      <div key={log.id} className="border-b border-[#252932]/40 pb-1 hover:bg-[#21252D]/40 transition-colors">
                        <span className="text-gray-600 font-bold mr-1.5">[{log.timestamp}]</span>
                        <span className={`mr-2 ${typeColor}`}>[{label}]</span>
                        <span className={`${log.isCommand ? 'text-[#00FF9C] font-bold' : 'text-gray-300'}`}>
                          {log.message}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Terminal Status bar */}
            <div className="bg-[#15181F] px-4 py-2 border-t border-[#2A2D35] flex justify-between items-center text-[9px] text-gray-500">
              <span className="flex items-center gap-1 font-mono uppercase tracking-wider">
                <span className="h-1.5 w-1.5 rounded-full bg-[#00FF9C] animate-ping" />
                9600 BAUD LINK
              </span>
              <span>Buffer: {logs.length}/150</span>
            </div>
          </div>
        </div>

      </main>

      {/* Footer information */}
      <footer className="bg-[#15181F] text-gray-500 text-center py-6 border-t border-[#2A2D35] shrink-0 text-xs">
         <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p>© 2026 MSGTIME System Project Manager. Created for Sagar.</p>
          <div className="flex gap-4 font-mono text-[10px] tracking-wider uppercase">
            <span>mDNS: <strong className="text-[#00FF9C]">Active</strong></span>
            <span>Subnet Scan CORS: <strong className="text-[#00FF9C]">Supported</strong></span>
            <span>Baud Rate: <strong className="text-[#00FF9C]">9600</strong></span>
          </div>
        </div>
      </footer>

    </div>
  );
}
