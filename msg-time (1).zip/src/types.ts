export interface BellPeriod {
  id: number;
  periodName: string;
  hour: number;
  minute: number; // mapped to 'second' / 'minute'
  duration: number; // in seconds
}

export interface SystemLog {
  id: string;
  timestamp: string;
  type: 'ESP32' | 'STM32' | 'APP' | 'SYSTEM';
  message: string;
  isCommand?: boolean;
}

export interface Holiday {
  id: string;
  date: string;
  label: string;
}
